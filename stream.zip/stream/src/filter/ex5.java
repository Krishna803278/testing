package filter;

import java.nio.file.DirectoryStream.Filter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ex5 {
	// private static List < Product > productsList = new ArrayList < Product > ();
	public static void main(String[] args) {
//		
//		List<String> in = Arrays.asList("a","d","s","w","r");
		
//		System.out.println(in);
		
//		Stream<Object> i=	in.stream().map(String::toUpperCase);
//		List<String> i2= in.stream().map(m->m.toUpperCase()).collect(Collectors.toList());
//		
//		
//		System.err.println(i);
//		System.err.println(i2);
		
		List<String> intr = new ArrayList<String>();

		intr.add("banna");
		intr.add("apple");
		intr.add("");
		intr.add("orange");
		intr.add("custed applie");
		intr.add("");
		intr.add("kaliflower");
 
		System.out.println(intr);
		
		System.out.println("###################################");
		
		List<String> l = intr.stream().map(String::toUpperCase).collect(Collectors.toList());
		
		System.out.println(l);
		
		System.out.println("###################################");
		
	    intr.stream().map(m->m.toUpperCase()).forEach(sys->System.out.println(sys));
	    
	    intr.stream().map(sys->sys.length()).forEach(System.out::println);
	    
	    System.out.println("###################################");
	    
	    System.out.println("count");
		long it =intr.stream().count();
	    System.out.println(it);
	    
	    System.out.println("###################################");
	    
	    System.out.println("count");
		long count =intr.stream().filter(x->x.isEmpty()).count();
	    System.out.println(count);
	    
	}

}
