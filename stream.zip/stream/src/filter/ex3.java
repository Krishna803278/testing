package filter;

import java.util.ArrayList;

public class ex3 {
	//private static Object characterCountMap;

	public static void main(String[] args) {
		ArrayList<Integer> nums = new ArrayList<Integer>();
        nums.add(1);
        nums.add(10);
        nums.add(10);
        nums.add(10);
        float sum = 0;
         
        //compute sum
        for(int num:nums) {
            sum += num;
          
        }
         
        //compute average
        float average = (sum / nums.size()); 
         
        System.out.println("Average : "+average);
//	}
		  
	}
}
