package filter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class ex4 {

	public static void main(String[] args) {

		List<Product2> prd = new ArrayList<Product2>();

		prd.add(new Product2(1, "A", 12, "fmale", 3000, 10099));
		prd.add(new Product2(2, "b", 22, "male", 1090, 199000));
		prd.add(new Product2(3, "c", 44, "male", 1800, 11000));
		prd.add(new Product2(4, "d", 54, "fmale", 1400, 1000));
		prd.add(new Product2(5, "e", 11, "fmale", 2020, 88000));
		prd.add(new Product2(1, "A", 2, "fmale", 3000, 10099));
		prd.add(new Product2(1, "A", 11, "male", 3000, 10099));
		prd.add(new Product2(1, "A", 19, "fmale", 3000, 10099));
		//System.out.println(prd);

		System.out.println("###################################");
//
		prd.stream().forEach(System.out::println);
//
//		System.out.println("###################################");
//
		Map<String, Long> map = prd.stream().collect(Collectors.
		                   groupingBy(Product2::getGender, Collectors.counting()));

		 //System.out.println(map);
//
//		System.out.println("###################################8989");
//
//		// prd.stream().map(s->s.getPrice()).distinct().forEach(System.out::println);
		prd.stream().filter(s->s.getYear()<3000).map(s->s.getName()) .forEach(System.out::println);
//
//		System.out.println("###################################");
//
//		Map<String, Double> map1 = prd.stream()
//				.collect(Collectors.groupingBy(Product2::getGender, Collectors.averagingInt(Product2::getAge)));
//
//		System.out.println(map1);
//
//		System.out.println("###################################1");
//		Optional<Product2> optional = prd.stream().collect(Collectors.maxBy(Comparator.comparing(Product2::getPrice)));
//		//System.out.println(optional.get().getName());
//		
//		Optional<Product2> optional1 = prd.stream().collect(Collectors.minBy(Comparator.comparing(Product2::getPrice)));
//		System.out.println(optional1);
//		System.out.println("###################################");
//
//		prd.stream().filter(s -> {
//			if (s.getName().equals("e") && s.getAge() < 20) {
//				s.setPrice(s.getPrice() + 66);
//				return true;
//			} else {
//				return false;
//			}
//		}).forEach(System.out::println);
//		
//		System.out.println("###################################");
	Optional<Product2> optional2=	prd.stream().filter(s-> s.getGender().equalsIgnoreCase("fmale")&& s.getAge()>15)
		.max(Comparator.comparing(Product2::getPrice));

		
		//System.out.println(optional2.get());
		
		System.out.println("###################################");
		
		Map<String ,Long> list=
				
	    prd.stream().filter(s->s.getGender().equalsIgnoreCase("fmale") && s.getName().equals("A"))
	    .collect(Collectors.groupingBy(Product2::getGender,Collectors.counting()));
		
		System.err.println(list);
		
	}

}
