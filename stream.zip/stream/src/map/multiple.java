package map;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class multiple {
	// private static List < Product > productsList = new ArrayList < Product > ();
	public static void main(String[] args) {

		
		List<Integer> intr = new ArrayList<>();

		intr.add(1);
		intr.add(2);
		intr.add(3);
		intr.add(4);
		intr.add(5);
		intr.add(6);
 
		System.out.println(intr);
		
		intr.stream().map(sys->sys*sys).forEach(System.out::println);
	    
	}

}
