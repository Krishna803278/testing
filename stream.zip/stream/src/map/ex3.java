package map;

import java.util.stream.Stream;

public class ex3 {
	// private static List < Product > productsList = new ArrayList < Product > ();
	public static void main(String[] args) {
		Stream.iterate(100, e -> e + 1).filter(e -> e % 5 == 0).limit(10) .forEach(System.out::println);

//		Stream.iterate(1, element->element+1)
//        .filter(element->element%5==0)  
//        .limit(10) 
//        .forEach(System.out::println);  
	}

}
