package map;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import stream.Product;

public class ex2 {
	// private static List < Product > productsList = new ArrayList < Product > ();
	public static void main(String[] args) {

		ArrayList<Product> intr = new ArrayList<Product>();

		intr.add(new Product(1, "A", 111,22000));
		intr.add(new Product(2, "B", 22, 24000));
		intr.add(new Product(3, "C", 13, 26000));
		intr.add(new Product(4, "D", 55, 253000));
		intr.add(new Product(5, "f", 10, 5300));
 
		
		
		System.out.println(intr);
		
		intr.stream().map(sys->sys.getPrice()>25000).forEach(System.out::println);
		
		
	}

}
