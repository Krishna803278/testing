package stream;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class ex4 {
	// private static List < Product > productsList = new ArrayList < Product > ();
	public static void main(String[] args) {

		List<String> intr = new ArrayList<String>();

		intr.add("banna");
		intr.add("apple");
		intr.add("mango");
		intr.add("orange");
		intr.add("custed applie");
		intr.add("drumstrick");
		intr.add("kaliflower");
 
		System.out.println(intr);
		System.out.println("###################################");

		List<String> l = intr.stream().map(String::toUpperCase).collect(Collectors.toList());
		
		System.out.println(l);
		System.out.println("################# sorted ##################");

		List<String> l1 = intr.stream().sorted((i1, i2) -> i1.compareTo(i2)).collect(Collectors.toList());
		List<String> l2 = intr.stream().sorted(Comparator.naturalOrder()).collect(Collectors.toList());
		System.err.println(l1);
		System.err.println(l2);

		System.out.println("###################################");

		List<String> l3 = intr.stream().sorted((i1, i2) -> i2.compareTo(i1)).collect(Collectors.toList());
		List<String> l4 = intr.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.err.println(l3);
		System.err.println(l4);
	}

}
