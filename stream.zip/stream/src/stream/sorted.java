package stream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class sorted {
	// private static List < Product > productsList = new ArrayList < Product > ();
	public static void main(String[] args) {

		ArrayList<Product> list = new ArrayList<Product>();

		list.add(new Product(1, "A", 111, 22000f));
		list.add(new Product(2, "B", 22, 24000f));
		list.add(new Product(3, "C", 13, 26000f));
		list.add(new Product(4, "D", 55, 253000f));

		System.out.println(list);
		System.out.println("###################################");

		System.out.println("print only names");
		List<String> product = list.stream().map(Product::getName).collect(Collectors.toList());

		System.out.println(product);

		System.out.println("###################################");

		System.out.println("print asd order");
		list.stream().sorted((o1, o2) -> o2.getAge() - o1.getAge()).forEach(System.out::println);
		// .collect(Collectors.toList());

		// System.out.println(products);

		System.out.println("###################################");

		System.out.println("print asd order");
		List<Product> products1 = list.stream().sorted(Comparator.comparing(Product::getAge))
				.collect(Collectors.toList());

		// System.out.println(products1);

		System.out.println("###################################");

		System.out.println("print rev order");
		List<Product> products2 = list.stream().sorted(Comparator.comparing(Product::getAge).reversed())
				.collect(Collectors.toList());

		// System.out.println(products2);

		System.out.println("###################################");

		System.out.println("print rev order By Name");
		List<Product> products3 = list.stream().sorted(Comparator.comparing(Product::getName).reversed())
				.collect(Collectors.toList());

		System.out.println(products3);

		System.out.println("###################################");

		System.out.println("print  order By Name");
		List<Product> products4 = list.stream().sorted(Comparator.comparing(Product::getName))
				.collect(Collectors.toList());

		System.out.println(products4);
		System.out.println();
		System.out.println("print rev order By id");
		List<Product> products = list.stream().sorted(Comparator.comparing(Product::getId).reversed())
				.collect(Collectors.toList());
		System.out.println(products);
		products.stream().forEach(s-> System.err.println(s));
		
	}

}
