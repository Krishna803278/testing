package com.tesng.parameters;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class parameter {


	WebDriver driver;

	@Parameters("browserName")
	@Test
	public void launchApp(String browserName) {
		switch (browserName.toLowerCase()) {
			case "chrome":
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				driver.get("https://www.javaguides.net/");
				break;
			case "edge":
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
				driver.get("https://www.javaguides.net/");
				break;
			default:
				throw new IllegalArgumentException("Unexpected value");
		}
	}
}
