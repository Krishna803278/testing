package com.tesng.mytest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tesng.abstractcomponts.AbstractCompont;

public class ProductCatalog extends AbstractCompont {

	WebDriver driver;

	public ProductCatalog(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = ".mb-3")
	List<WebElement> prodects;

	@FindBy(id = "toast-container")
	WebElement wait;

	@FindBy(css = ".infoWrap h3")
	List<WebElement> cardProdects;

	By prodectBy = By.cssSelector(".mb-3");

	By addToCard = By.cssSelector(".card-body button:last-child");

	public List<WebElement> getProdectList() {
		waitForElementToAppeare(prodectBy);
		return prodects;
	}

	public WebElement getProdectName(String prodectName) {
		WebElement prod = getProdectList().stream()
			.filter(x -> x.findElement(By.cssSelector("b")).getText().equals(prodectName)).findFirst().orElse(null);
		// waitForElementToAppeare(prodectBy);
		return prod;
	}

	public void addToProdect(String prodectName) {
		WebElement prod = getProdectName(prodectName);
		prod.findElement(addToCard).click();
		waitElementToInvisibleMOde(wait);
	}
	// public Boolean cartBox(String prodectName) {
	// Boolean match = cardProdects.stream().anyMatch(x -> x.getText().equalsIgnoreCase(prodectName));
	// return match;
	// }
}
