package com.tesng.mytest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.tesng.abstractcomponts.AbstractCompont;

public class CartPage extends AbstractCompont {

	WebDriver driver;

	public CartPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = ".infoWrap h3")
	List<WebElement> cardProdects;
	
	@FindBy(xpath = "//input[@placeholder='Select Country']")
	WebElement sendCountryName;
	
	By waitUntillelementsVisisble = By.cssSelector("//button[@type='button']//span");
	
	// @FindBy(xpath = "//button[@type='button']//span")
	@FindBy(css = "button[type='button']span")
	List<WebElement> selectCountryName;

	private By buttonLocator = By.cssSelector("button[type='button']span");

	//private final By searchBoxLocator = By.xpath("//input[@placeholder='Select Country']");
	// By searchBoxLocator = By.cssSelector("//div[@class='form-group']");

	@FindBy(css = "//div[@class='form-group']")
	WebElement wait;
	//

	public Boolean cartBox(String prodectName) {
		Boolean match = cardProdects.stream().anyMatch(x -> x.getText().equalsIgnoreCase(prodectName));
		return match;
	}
	public void serchBoxValve( String countryName) {
		sendCountryName.sendKeys(countryName);
		  waitForElementToAppeare(waitUntillelementsVisisble);

	}
	  public List<WebElement> getSelectCountryName() {
			waitForElementToAppeare(waitUntillelementsVisisble);
	        return selectCountryName;
	    }

//	public static void multiSelectMethod(List<WebElement> elements, String valve) {
//		for (WebElement webElement : elements) {
//			if (webElement.getText().equals(valve)) {
//				webElement.click();
//				break;
//			}
//		}
//	}
// public void selectCountry(String countryName) {
// for (WebElement element : selectCountryName) {
// if (element.getText().equalsIgnoreCase(countryName)) {
// element.click();
// break;
// }
// }
// }
public void clickButtonByText(String buttonText) {
	List<WebElement> buttons = driver.findElements(buttonLocator);
	for (WebElement button : buttons) {
		if (button.getText().equals(buttonText)) {
			button.click();
	                break;
	            }
	        }
	    }
}
