package com.tesng.OrangeHrms;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MyTest {

	WebDriver driver;

	@Parameters("browserName")
	@Test
	public void InitialiseBrowser(String browserName) {
		switch (browserName) {
			case "chrom":
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
				break;
			case "edge":
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
				break;
			case "firefox":
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
				break;
			default:
				System.err.println("value not a browser");
				break;
		}
		driver.manage().window().maximize();
	}

	@Parameters("url")
	@Test
	public void lunchApp(String url) {
		driver.get(url);
	}
	// @AfterTest
	// public void closeApp() {
	// driver.quit();
	// }

	@Test
	public void getTitle() throws InterruptedException {
		// driver.get("https://www.amazon.in/");
		// driver.manage().window().maximize();
		List<WebElement> links = driver.findElements(By.xpath("//div[@id='nav-xshop']//a"));
		System.out.println(" TotalLinks : " + links.size());
		System.out.println(" page Title : " + driver.getTitle());
		// Thread.sleep(3000);
	}

	@Test
	public void goAccountPage() throws InterruptedException {
		driver.findElement(By.xpath("//a[@id='nav-hamburger-menu']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//li[.='Your Account']")).click();
		driver.navigate().back();
	}

	@Test
	public void goBucketPage() throws InterruptedException {
		// driver.get("https://www.amazon.in/");
		// driver.manage().window().maximize();
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
		driver.findElement(By.id("nav-cart")).click();
		System.err.println("page Title :"
			+ driver.findElement(By.xpath("//h2[normalize-space()='Your Amazon Cart is empty']")).getText());
		driver.navigate().back();
	}

	@Test
	public void goSearch() throws InterruptedException {
		// driver.get("https://www.amazon.in/");
		// driver.manage().window().maximize();
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(1000));
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("mobile", Keys.ENTER);
		Thread.sleep(3000);
		driver.navigate().back();
	}
}
