package com.tesng.rahul;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.tesng.mytest.CartPage;
import com.tesng.mytest.ProductCatalog;
import com.tesng.mytest.landingPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StandAloneTest {

	public static void main(String[] args) throws InterruptedException {
		String prodectName = "ADIDAS ORIGINAL";
		String countryName = "ind";
		 String selectName = "India";

		WebDriverManager.edgedriver().setup();
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.manage().window().maximize();
		landingPage landingPage = new landingPage(driver);
		landingPage.goTo();
		landingPage.logInApplication("zxy12@gmail.com", "Abc@1234");
		ProductCatalog productCatalog = new ProductCatalog(driver);
		productCatalog.getProdectList();
		productCatalog.addToProdect(prodectName);
		productCatalog.getProdectList();
		CartPage cartPage = new CartPage(driver);
		cartPage.clickCartBox();
		Boolean match = cartPage.cartBox(prodectName);
		// assertTrue(match);
		cartPage.checkOut();
		cartPage.serchBoxValve(countryName);
		Thread.sleep(1000);
		cartPage.clickButtonByText(selectName);
		// cartPage.selectCountry(selectName);
//		driver.findElement(By.cssSelector(".btnn")).click();
//		String str = driver.findElement(By.cssSelector(".hero-primary")).getText();
//		assertEquals(str, "THANKYOU FOR THE ORDER.");
//		System.err.println(str);
	}
}
