package com.tesng.dependence;

import org.testng.annotations.Test;

public class Dependence {

	static String trakingNumber = null;

	// @Test()
	// public void createShipment() {
	// System.err.println(5 / 0);
	// System.err.println("createShipment");
	// trakingNumber = "abc12yh"
	// }

	@Test(alwaysRun = true, ignoreMissingDependencies = true, dependsOnMethods = {"createShipment"})
	public void trackingShipment() throws Exception {
		// System.err.println(5 / 0);
		if (trakingNumber != null)
			System.err.println("trackingShipment");
		else
			throw new Exception("Invalid trakingNumber number");
	}

	@Test(dependsOnMethods = {"trackingShipment", "trackingShipment"})
	public void cancleShipment() throws Exception {
		// System.err.println("cancleShipment");
		if (trakingNumber != null)
			System.err.println("cancleShipment");
		else
			throw new Exception("Invalid trakingNumber number");
	}

	// @Test(groups = {"sanity", "regression"})
	// public void test4() {
	// System.err.println("newTest1 test4");
	// }
}
