package com.tesng;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestNgApplicationTests {

	@Test
	void contextLoads() {
	}

}
