package com.tesng.group;

import org.testng.annotations.Test;

public class newTest1 {

	@Test(groups = {"smoke"})
	public void test1() {
		System.err.println("newTest1  test1");
	}

	@Test(groups = {"sanity", "functional"})
	public void test2() {
		System.err.println("newTest1  test2");
	}

	@Test(groups = {"functional", "regression"})
	public void test3() {
		System.err.println("newTest1  test3");
	}

	@Test(groups = {"sanity", "regression"})
	public void test4() {
		System.err.println("newTest1  test4");
	}
}
