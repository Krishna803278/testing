package com.tesng.group;

import org.testng.annotations.Test;

@Test(groups = {"all"})
public class newTest2 {

	@Test(groups = {"smoke"})
	public void test1() {
		System.err.println("newTest2  test1");
	}

	@Test(groups = {"smoke", "functional"})
	public void test2() {
		System.err.println("newTest2    test2");
	}

	@Test(groups = {"functional", "regression"})
	public void test3() {
		System.err.println("newTest2   test3");
	}

	@Test(groups = {"sanity", "regression"})
	public void test4() {
		System.err.println("newTest2   test4");
	}
}
