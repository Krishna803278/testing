package com.tesng.dataprovider;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderr {

	@Test(dataProvider = "dp1")
	public  void test(String str) {
		System.err.println("fetching valve from DataProvider : " +str);
	}

	@DataProvider(name = "dp1")
	public String []dp(){
		String[] std = new String[] {
			"hyr",
			"vig",
			"kdr",
			"bangloor",
		};
		return std;
		
	}
}
