package com.example.demo.screenshot;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class MainCode extends BaseTest {
	@BeforeMethod
	public void setup() {
		initializeDriver();
	}

	@Test(testName = "launchApp")
	public void launchApp() {

		driver.get("https://www.overleaf.com/");
		System.err.println(driver.getTitle());
		assertEquals(driver.getTitle(), "Overleaf, Online LaTeX Editor");

	}

	@Test(testName = "launchAppfaile")
	public void launchAppfaile() throws InterruptedException {

		driver.get("https://www.overleaf.com/");
		driver.findElement(By.xpath("//a[normalize-space()='Sign up']")).click();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("bkreddy1316@gmail.com");

		Thread.sleep(1000);
		driver.findElement(By.id("passwordField")).sendKeys("Kri@(1998)r");

		driver.findElement(By.xpath("//div[@class='actions']")).click();
	}
}
