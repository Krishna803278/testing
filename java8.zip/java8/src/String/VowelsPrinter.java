package String;

public class VowelsPrinter {
    public static void main(String[] args) {
        String inputString = "streamsandlambdaexpressions";

        // Printing vowels using Java 8 Streams and Lambda Expressions
        System.out.println("Vowels in the input string:");
        inputString.chars()
                .mapToObj(c -> (char) c)
                .filter(c -> isVowel(c)) //for print vowels
                //.filter(c ->! isVowel(c))// //for print non  vowels
                .forEach(System.out::println);
    }

    private static boolean isVowel(char c) {
        char lowerCaseChar = Character.toLowerCase(c);
        return lowerCaseChar == 'a' || lowerCaseChar == 'e' || lowerCaseChar == 'i' || lowerCaseChar == 'o' || lowerCaseChar == 'u';
    }
}
