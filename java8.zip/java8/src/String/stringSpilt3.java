package String;

import java.util.Arrays;
import java.util.stream.Collectors;

public class stringSpilt3 {

	public static void main(String[] args) {
		String input = "1This2Is3My4Happy5Cooding";

		String output = Arrays.stream(input.split("(?=[A-Z])")).collect(Collectors.joining(" "));
		System.out.println(output);
		System.out.println("====================================================");
		String input1 = "Th1is2Is3My4Happy5Cooding";
		String[] words = input1.split("([0-9])");

		Arrays.stream(words)
        .map(String::trim)
        .forEach(System.out::println);
		

	}
}
