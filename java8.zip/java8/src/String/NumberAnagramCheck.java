package String;

import java.util.Arrays;

public class NumberAnagramCheck {
	public static boolean numberAnagramCheck(int num1, int num2) {

		String Str1 = String.valueOf(num1);
		String Str2 = String.valueOf(num2);

		char[] charArray1 = Str1.toCharArray();
		char[] charArray2 = Str2.toCharArray();
		Arrays.sort(charArray1);
		Arrays.sort(charArray2);

		return Arrays.equals(charArray1, charArray2);

	}

	public static void main(String[] args) {
		int num1 = 21;
		int num2 = 22;
		if (numberAnagramCheck(num1, num2)) {
			System.out.println(num1 + " and " + num2 + " are anagrams.");
		} else {
			System.out.println(num1 + " and " + num2 + " are not anagrams.");
		}

	}
}
