package String;

import java.util.HashMap;
import java.util.Map;

public class VowelsCounter {
	public static void main(String[] args) {
        String inputString = "streamsandlambdaexpressions";

        // Printing vowels using Java 8 Streams and Lambda Expressions
        System.out.println("Vowels in the input string:");
        Map<Character, Integer> vowelCount = new HashMap<>();
        inputString
                .chars()
                .mapToObj(c -> (char) c)
                .filter(c -> isVowel(c)) // Filter only vowels
                .forEach(c -> vowelCount.put(c, vowelCount.getOrDefault(c, 0) + 1));

        System.out.println("Vowel character count in the input string:");
        vowelCount.entrySet().stream()
                .forEach(entry -> System.out.println(entry.getKey() + " : " + entry.getValue()));
    }

    private static boolean isVowel(char c) {
        char lowerCaseChar = Character.toLowerCase(c);
        return lowerCaseChar == 'a' || lowerCaseChar == 'e' || lowerCaseChar == 'i' || lowerCaseChar == 'o' || lowerCaseChar == 'u';
    }
}
