package String;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;

public class LongestSubstring {
	 public static String findLongestSubstring(String input) {
	        int maxLength = 0;
	        String longestSubstring = "";
	        int start = 0;
	        int end = 0;
	        HashSet<Character> charSet = new HashSet<>();

	        while (end < input.length()) {
	            char currentChar = input.charAt(end);
	            if (!charSet.contains(currentChar)) {
	                charSet.add(currentChar);
	                if (end - start + 1 > maxLength) {
	                    maxLength = end - start + 1;
	                    longestSubstring = input.substring(start, end + 1);
	                }
	                end++;
	            } else {
	                charSet.remove(input.charAt(start));
	                start++;
	            }
	        }

	        return longestSubstring;
	    }

	    public static void main(String[] args) {
	        String input = "javaconceptoftheday";
	        String longestSubstring = findLongestSubstring(input);
	        System.out.println("Longest substring without repeating characters: " + longestSubstring);
	        System.out.println("Length: " + longestSubstring.length());
	    }

}
