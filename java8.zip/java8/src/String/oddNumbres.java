package String;

import java.util.stream.Stream;

public class oddNumbres {
	public static void main(String[] args) {
		Stream.iterate(new int[] { 1, 3 }, f -> new int[] { f[1], f[1] + 2 })
		.limit(10)
		.map(f -> f[0])
		.forEach(i -> System.out.print(i + " "));
		
		System.out.println("=====================================");
		
		Stream.iterate(new int[] { 1, 2 }, f -> new int[] { f[1], f[1] + 2 })
		.limit(10)
		.map(f -> f[0])
		.forEach(i -> System.out.print(i + " "));
		System.out.println("==================fibnasi===================");

		Stream.iterate(new int [] {0,1}, f->new int[] {f[1],f[0]+f[1]})
		.limit(10)
		.map(f->f[0])
		.forEach(i -> System.out.print(i + " "));
	
		System.out.println("=====================================");

	}

}
