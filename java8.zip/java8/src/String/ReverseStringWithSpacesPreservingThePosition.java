package String;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReverseStringWithSpacesPreservingThePosition {

	public static void main(String[] args) {
		String word = "Java Concept Of The Day";
		String[] words = word.split(" ");
		String wordss = word.replaceAll(" ", " ").toLowerCase();

		String reversedString = 
				Stream.of(wordss)
				.map(w -> new StringBuilder(w).reverse().toString())
				.collect(Collectors.joining(" "));
		
		System.out.println("orginal string: " + word);
		System.out.println("Reversed string: " + reversedString);
	}
}
