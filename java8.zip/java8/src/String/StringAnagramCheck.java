package String;

import java.util.Arrays;

public class StringAnagramCheck {
	public static boolean StringAnagramCheck(String str1, String str2) {
		String st1 = str1.replace(" ", "").toLowerCase();
		String st2 = str2.replace(" ", "").toLowerCase();

		if (st1.length() != st2.length()) {
			return false;
		}

		char[] char1 = st1.toCharArray();
		char[] char2 = st2.toCharArray();
		Arrays.sort(char1);
		Arrays.sort(char2);

		return Arrays.equals(char1, char2);

	}

	public static void main(String[] args) {
		String str1 = "listen";
		String str2 = "silent";

		if (StringAnagramCheck(str1, str2)) {
			System.out.println(str1 + " and " + str2 + " are anagrams.");
		} else {
			System.out.println(str1 + " and " + str2 + " are not anagrams.");
		}

	}
}
