package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class DuplicateNumbersCounter {
	public static void main(String[] args) {

		// List<Integer> numbers = List.of(1, 2, 3, 1, 4, 2, 5);
		List<Integer> numbers = Arrays.asList(1, 2, 3, 1, 4, 2, 5);
		Map<Object, Long> counts = numbers.stream().collect(Collectors.groupingBy(s -> s,LinkedHashMap::new, Collectors.counting()));

		// counts.entrySet().stream().forEach(s->System.out.println(s.getKey() +"
		// "+s.getValue()));
		System.err.println();
//		counts.entrySet().stream().filter(s -> s.getValue() > 1)
//				.forEach(s -> System.out.println(s.getKey() + "  " + s.getValue()));

		System.out.println("//////////////////////////////////////////////");

		System.err.println();
		// From the given list of integers, print the numbers which are multiples of 5
		List<Integer> listOfIntegers = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);

		listOfIntegers.stream().filter(i -> i % 5 == 0).forEach(System.out::println);

		System.out.println("//////////////////////////////////////////////");
		// Given a list of integers, find maximum and minimum of those numbers
		List<Integer> listOfInteger = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);

		int max = listOfInteger.stream().max(Comparator.naturalOrder()).get();

		System.out.println("Maximum Element : " + max);

		int min = listOfInteger.stream().min(Comparator.naturalOrder()).get();

		System.out.println("Minimum Element : " + min);

		System.out.println("////////////////////////////////////////////////////////////////");

		int[] a = new int[] { 4, 2, 5, 1 };

		int[] b = new int[] { 8, 1, 9, 5 };

		int[] c = IntStream.concat(Arrays.stream(a), Arrays.stream(b)).sorted().distinct().toArray();
		System.out.println(Arrays.toString(c));

		System.out.println("////////////////////////////////////////////////////////////////");

		List<String> listOfStrings = Arrays.asList("Java", "Python", "C#", "HTML", "Kotlin", "C++", "COBOL", "C");

		listOfStrings.stream().sorted(Comparator.comparing(String::length)).forEach(System.out::println);

		System.out.println("////////////////////////////////////////////////////////////////");

		List<String> listOfString = Arrays.asList("Java", "Python", "C#", "HTML", "Kotlin", "C++", "COBOL", "C");

		listOfString.stream() .sorted(Comparator.comparing(String::length).reversed()).forEach(System.out::println);
		System.out.println("////////////////////////////////////////////////////////////////");

	
	System.out.println("////////////////////////////////////////////////////////////////");
	
}

}
