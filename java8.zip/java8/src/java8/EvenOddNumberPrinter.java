package java8;

import java.util.stream.IntStream;

public class EvenOddNumberPrinter {
	public static void main(String[] args) {

		System.out.println("Prime numbers:");
		IntStream.rangeClosed(2, 50).filter(EvenOddNumberPrinter::isPrime).forEach(System.out::println);

	}
	public static boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        return IntStream.rangeClosed(2, (int) Math.sqrt(number))
                .noneMatch(i -> number % i == 0);
    }
}
