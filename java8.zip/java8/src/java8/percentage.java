package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class percentage {
	public static void main(String[] args) {

		String text = "Tiger Runs @ The Speed Of 100 km/hour.";

		// Calculate the total length of the string
		int totalLength = text.length();

		// Calculate the count of uppercase letters using streams and filter
		long uppercaseCount = text.chars().filter(Character::isUpperCase).count();
		// Calculate the count of lowercase letters using streams and filter
		long lowercaseCount = text.chars().filter(Character::isLowerCase).count();
		// Calculate the count of digits using streams and filter
		long digitCount = text.chars().filter(Character::isDigit).count();
		// Calculate the count of special characters using streams and filter
		long specialCharCount = text.chars().filter(c -> !Character.isLetterOrDigit(c)).count();
		long spaces = text.chars().filter(c -> c != ' ').count();
		System.out.println(spaces);
		System.out.println(digitCount);
		System.out.println(specialCharCount);
		System.out.println(lowercaseCount);
		System.out.println(uppercaseCount);
		// Calculate the percentages
		double uppercasePercentage = (uppercaseCount * 100.0) / totalLength;
		double lowercasePercentage = (lowercaseCount * 100.0) / totalLength;
		double digitPercentage = (digitCount * 100.0) / totalLength;
		double specialCharPercentage = (specialCharCount * 100.0) / totalLength;
		double spacePercentage = (spaces * 100.0) / totalLength;

		// Display the percentages
		System.out.printf("Uppercase Letters: %.2f%%\n", uppercasePercentage);
		System.out.printf("Lowercase Letters: %.2f%%\n", lowercasePercentage);
		System.out.printf("Digits: %.2f%%\n", digitPercentage);
		System.out.printf("Special Characters: %.2f%%\n", specialCharPercentage);
		System.out.printf("Space : %.2f%%\n", spacePercentage);

	}
}
