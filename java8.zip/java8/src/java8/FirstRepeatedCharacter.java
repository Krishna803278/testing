package java8;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FirstRepeatedCharacter {
	public static void main(String[] args) {
		  String inputString = "Java Concept Of The Day".replaceAll(" ", "").toLowerCase();
	         
	        Map<String, Long> charCountMap = 
	                            Arrays.stream(inputString.split(""))
	                                    .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));
	         
	        Entry<String, Long> firstRepeatedChar = charCountMap.entrySet()
	                                                .stream()
	                                                .filter(entry -> entry.getValue() > 1)
	                                                .findFirst()
	                                                .get();
	         
	        System.out.println(firstRepeatedChar);
	        System.out.println("==================================");
	        System.err.println("Displaying the character counts");
	        charCountMap.entrySet().stream().filter(s -> s.getValue() ==1)// >1;<2
					.forEach(s -> System.out.println(s.getKey() + "  " + s.getValue()));
		
	}
}
