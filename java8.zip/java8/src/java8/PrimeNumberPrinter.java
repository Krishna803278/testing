package java8;

import java.util.stream.IntStream;

public class PrimeNumberPrinter {
	public static void main(String[] args) {

		System.out.println("Even numbers:");
		System.out.println("Odd numbers:");

		IntStream.rangeClosed(1, 50).forEach(s -> System.err.println(s % 2 ==0 ?"Even"+s : "odd"+s));

		
	    System.out.println("Even numbers:");
        IntStream.rangeClosed(1, 50)
                .filter(num -> num % 2 == 0)
                .forEach(System.out::println);

        System.out.println("Odd numbers:");
        IntStream.rangeClosed(1, 50)
                .filter(num -> num % 2 != 0)
                .forEach(System.out::println);
    }
	}

