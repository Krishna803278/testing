package java8;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DuplicateStringCounter {
	public static void main(String[] args) {

		List<String> strings = List.of("apple", "banana", "apple", "orange", "banana", "apple");
		Map<String, Long> counts = strings.stream().collect(Collectors.groupingBy(s -> s, Collectors.counting()));

		counts.entrySet().stream().filter(s -> s.getValue() < 2)
				.forEach(s -> System.out.println(s.getKey() + "  " + s.getValue()));
		System.out.println("==========================================================================");
		String str = "Number of words in in the string";

		Map<String, Long> counts2 = Arrays.stream(str.split(" "))
				.collect(Collectors.groupingBy(s -> s, Collectors.counting()));
		//
		System.err.println("Displaying the words counts");
		counts2.entrySet().stream()// .filter(s -> s.getValue() > 1)
				.forEach(s -> System.out.println(s.getKey() + "  " + s.getValue()));

		System.out.println("==========================================================================");

		String text = "Number of character in the string";

		// Counting the occurrences of each character in the string
		Map<Character, Long> counts3 = text.chars().filter(c -> c != ' ')// if we comment this line it ll'l count the
																			// spaces also
				.mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		// Displaying character counts
		System.err.println("Displaying the character counts");
		counts3.entrySet().stream().filter(s -> s.getValue()>1)// >1;<2
				.forEach(s -> System.out.println(s.getKey() + "  " + s.getValue()));
		System.out.println("==========================================================================");

		String text2 = "Number of words in the string";

		long countOfN = text2.chars().filter(c -> c == 'N' || c == 'n') // Count both 'N' and 'n'
				.count();

		System.err.println("Displaying the paticular charecter counts");
		System.out.println("The letter 'N' appears " + countOfN + " times.");
		System.out.println("==========================================================================");

		StringBuffer buffer = new StringBuffer(text2);

		System.out.println(buffer.reverse());
		System.out.println("==========================================================================");

		String reversedString = Stream.of(text2).map(w -> new StringBuilder(w).reverse()).collect(Collectors.joining());
		System.out.println("Original String: " +text2);
		System.out.println("Reversed String: " +reversedString);

		System.out.println("==========================================================================");
		System.out.println("==========================================================================");
		String inputString = "I Am Not String";

        // Reversing each word using Java 8 Streams
        String reversedString2 = Arrays.stream(inputString.split(" "))
                .map(word -> new StringBuilder(word).reverse())
                .collect(Collectors.joining(" "));

        // Print the original and reversed strings
        System.out.println("Original String: " + inputString);
        System.out.println("Reversed String: " + reversedString2);
		System.out.println("==========================================================================");

		List<String> listOfStrings = Arrays.asList("Facebook", "Twitter", "YouTube", "WhatsApp", "LinkedIn");

		String joinedString = listOfStrings.stream().collect(Collectors.joining(" , ", "[", "]"));
		System.out.println(joinedString);
		System.out.println("==========================================================================");
		List<Integer> listOfIntegers = Arrays.asList(45, 12, 56, 15, 24, 75, 31, 89);

		int max = listOfIntegers.stream().max(Comparator.naturalOrder()).get();

		System.out.println("Maximum Element : " + max);

		int min = listOfIntegers.stream().min(Comparator.naturalOrder()).get();

		System.out.println("Minimum Element : " + min);

		System.out.println("==========================================================================");

		List<Double> decimalList = Arrays.asList(12.45, 23.58, 17.13, 42.89, 33.78, 71.85, 56.98, 21.12);

		Double maxx = decimalList.stream().max(Comparator.naturalOrder()).get();

		System.out.println("Maximum Element : " + maxx);

		System.out.println("==========================================================================");

		int i = 15623;

		Double sumOfDigits = Stream.of(String.valueOf(i).split("")).collect(Collectors.averagingInt(Integer::parseInt));
		Integer sumOfDigits2 = Stream.of(String.valueOf(i).split(""))
				.collect(Collectors.summingInt((Integer::parseInt)));

		System.out.println(sumOfDigits);
		System.out.println(sumOfDigits2);

		System.out.println("==========================================================================");

		List<Integer> listOfIntegers1 = Arrays.asList(111, 222, 333, 111, 555, 333, 777, 222);

		Set<Integer> uniqueElements = new HashSet<>();

		// Set<Integer> duplicateElements = listOfIntegers1.stream().filter(i -> !
		// uniqueElements.add(i)).collect(Collectors.toSet());

		// System.out.println(duplicateElements);

		System.out.println("==========================================================================");

		List<Integer> listOfIntegers2 = Arrays.asList(111, 222, 333, 111, 555, 333, 777, 222);

		Map<Integer, Long> map = listOfIntegers2.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		map.entrySet().stream().filter(s -> s.getValue() ==1)
				.forEach(s -> System.out.println(s.getKey() + "  " + s.getValue()));

	}
}
