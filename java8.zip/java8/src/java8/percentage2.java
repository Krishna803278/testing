package java8;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class percentage2 {
	public static void main(String[] args) {
		String str = "Java Concept Of The Day";
        Map<String, Long> map = str.chars()
                //.filter(Character::isUpperCase)
                .filter(Character::isSpaceChar)
               // .filter(ch -> !Character.isLetterOrDigit(ch))
                //.filter(Character::isDigit)
                .mapToObj(ch -> String.valueOf( ch))
                .collect(Collectors.groupingBy(Function.identity(),  Collectors.counting()));

        long capitalCount = map.values().stream()
                .mapToLong(Long::valueOf)
                .sum();

        System.out.println("Number of capital letters in the string: " + capitalCount);
     }
	
}
