package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class StringWordsCount {
	public static void main(String[] args) {
		Integer[] arrays = { 45, 12, 56, 15, 24, 75, 31, 89 };
		List<Integer> listOfIntegers = Arrays.asList(arrays);

		Integer secondLargestNumber = listOfIntegers.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst()
				.get();
		int i =listOfIntegers.stream().max(Comparator.naturalOrder()).get();
		listOfIntegers.stream().sorted(Comparator.reverseOrder()).limit(2).forEach(System.out::println);
		System.out.println("List: " + secondLargestNumber);
		System.out.println("List: " + i);
	}
}
