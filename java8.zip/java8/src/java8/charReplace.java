package java8;

import java.util.LinkedHashSet;
import java.util.stream.Collectors;

public class charReplace {
	public static void main(String[] args) {

		String st = "chranch";
		char c = 'c';
		String srt = Replace(st, c);
		System.out.println(srt);
		System.out.println("====================");
		String st1 = "c3hra1nch";
        String srt2 = removeNumbers(st1);
        System.out.println(srt2);
        System.out.println("====================");
        String st3 = "c@hr$a,as123nch)&";
        String srt3 = removeDuplicates(st3);
        System.out.println(srt3);
    }

	

	public static String Replace(String str, char che) {

		return str.chars()
				.filter(c -> c != che)
				.mapToObj(Character::toString)
				.collect(Collectors.joining());

	}
	 public static String removeNumbers(String str) {
	        return str.chars()
	                .filter(c -> !Character.isDigit(c))
	                .mapToObj(Character::toString)
	                .collect(Collectors.joining());
	    }
	  public static String removeDuplicates(String str) {
	        return str.chars()
	        		  .filter(Character::isLetter)//  .distinct()
	                  .mapToObj(Character::toString)
	                  .collect(Collectors.joining());
	    }
}
