package java8;

import java.util.stream.Stream;

public class First_10_Fibonacci_numbers {
	public static void main(String[] args) {

		
		Stream.iterate(new int [] {0,1},fib->new int[] {fib[1],fib[0]+fib[1]}).limit(10)
        .forEach(fib -> System.out.print(fib[0] + " "));
	}
}
