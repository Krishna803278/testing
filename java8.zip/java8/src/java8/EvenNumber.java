package java8;

import java.util.stream.IntStream;

public class EvenNumber {
	public static void main(String[] args) {
		 IntStream.iterate(1, n -> n + 2)
         .limit(10)
         .forEach(System.out::println);
		 System.out.println("=============");
 //=================================================== not recomnded
		 IntStream.rangeClosed(0, 10).filter(i->i%2==0)
		 .limit(10)
		 .forEach(System.out::println);
    }
}
