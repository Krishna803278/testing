package java8;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class twoStringArrayCancat {
	
		
		public static void main(String[] args) {
	        String[] array1 = {"Hello", "Java"};
	        String[] array2 = {"Java", "Program"};

	        String[] mergedArray = Stream.concat(Arrays.stream(array1), Arrays.stream(array2)).sorted(Comparator.reverseOrder()).distinct()
	                                     .toArray(String[]::new);

	        // Print the merged array
	        System.out.println("Merged Array: " + Arrays.toString(mergedArray));
	        System.out.println("==========================");
	        
	        int[] a = new int[] {4, 2, 5, 1};
	         
	        int[] b = new int[] {8, 1, 9, 5};
	         
	        int[] c = IntStream.concat(Arrays.stream(a), Arrays.stream(b)).sorted().distinct().toArray();
	         
	        System.out.println(Arrays.toString(c));
	    }

	
}
