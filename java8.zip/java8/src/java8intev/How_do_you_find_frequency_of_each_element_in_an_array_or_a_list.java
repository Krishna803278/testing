package java8intev;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class How_do_you_find_frequency_of_each_element_in_an_array_or_a_list {
	public static void main(String[] args) {
		 List<String> stationeryList = Arrays.asList("Pen", "Eraser", "Note Book", "Pen", "Pencil", "Stapler", "Note Book", "Pencil");
         
	        Map<String, Long> stationeryCountMap =
	        stationeryList.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		 
		System.out.println(stationeryCountMap);
		stationeryCountMap.entrySet().stream() .filter(s -> s.getValue() >1).forEach(s->System.err.println(s.getKey() +" "+s.getValue()));
	}

}
