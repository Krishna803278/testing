package java8intev;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class oddEvenNumbersMap {
	public static void main(String[] args) 
    {
		List<Integer> listOfIntegers = Arrays.asList(71, 18, 42, 21, 67, 32, 95, 14, 56, 87);

	    listOfIntegers.stream()
	            .collect(Collectors.partitioningBy(i -> i % 2 == 0))
	            .forEach((key, value) -> {
	                System.out.println("--------------");
	                System.out.println(key ? "Even Numbers" : "Odd Numbers");
	                System.out.println("--------------");
					value.forEach(System.out::println);
	            });
    }

}
