package api.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class User {

	int id;

	String username;

	String firstName;

	String lastName;

	String email;

	String password;

	String phone;

	int userStatus;
}
