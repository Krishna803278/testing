package api.endpoint;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class ProjectApiTest3 {

	public static void main(String[] args) {
		String jsonString = "{\n" + "  \"projectId\": \"PROJ123456\",\n" + "  \"projectName\": \"AI Development\",\n"
			+ "  \"tasks\": [\n" + "    {\n" + "      \"taskId\": \"TASK001\",\n"
			+ "      \"taskName\": \"Design Model\",\n" + "      \"assignees\": [\n" + "        {\n"
			+ "          \"assigneeId\": \"USER001\",\n" + "          \"name\": \"Alice Smith\",\n"
			+ "          \"roles\": [\n" + "            {\n" + "              \"roleId\": 101,\n"
			+ "              \"roleName\": \"Data Scientist\"\n" + "            },\n" + "            {\n"
			+ "              \"roleId\": 102,\n" + "              \"roleName\": \"Team Lead\"\n" + "            }\n"
			+ "          ]\n" + "        },\n" + "        {\n" + "          \"assigneeId\": \"USER002\",\n"
			+ "          \"name\": \"Bob Johnson\",\n" + "          \"roles\": [\n" + "            {\n"
			+ "              \"roleId\": 103,\n" + "              \"roleName\": \"Data Engineer\"\n" + "            }\n"
			+ "          ]\n" + "        }\n" + "      ],\n" + "      \"subtasks\": [\n" + "        {\n"
			+ "          \"subtaskId\": \"SUBTASK001\",\n" + "          \"subtaskName\": \"Gather Data\",\n"
			+ "          \"dueDate\": \"2024-09-01\"\n" + "        },\n" + "        {\n"
			+ "          \"subtaskId\": \"SUBTASK002\",\n" + "          \"subtaskName\": \"Clean Data\",\n"
			+ "          \"dueDate\": \"2024-09-15\"\n" + "        }\n" + "      ]\n" + "    }\n" + "  ],\n"
			+ "  \"milestones\": [\n" + "    {\n" + "      \"milestoneId\": \"MILE001\",\n"
			+ "      \"milestoneName\": \"Phase 1 Completion\",\n" + "      \"dueDate\": \"2024-10-01\"\n" + "    }\n"
			+ "  ],\n" + "  \"budget\": {\n" + "    \"total\": 500000,\n" + "    \"currency\": \"USD\",\n"
			+ "    \"allocated\": [\n" + "      {\n" + "        \"department\": \"R&D\",\n"
			+ "        \"amount\": 300000\n" + "      },\n" + "      {\n" + "        \"department\": \"Marketing\",\n"
			+ "        \"amount\": 200000\n" + "      }\n" + "    ]\n" + "  }\n" + "}";

		// Parse the JSON string into a JSONObject
		JSONObject jsonObject = new JSONObject(jsonString);

		// Create a list to store the roleName values
		List<String> roleNames = new ArrayList<>();
		JSONArray tasks = jsonObject.getJSONArray("tasks");
		for (int i = 0; i < tasks.length(); i++) {
			JSONObject task = tasks.getJSONObject(i);
			JSONArray assignees = task.getJSONArray("assignees");
			for (int j = 0; j < assignees.length(); j++) {
				JSONObject assignee = assignees.getJSONObject(j);
				
				JSONArray roles = assignee.getJSONArray("roles");
				if (assignee.getString("name").equals("Bob Johnson")) {
				for (int k = 0; k < roles.length(); k++) {
					JSONObject role = roles.getJSONObject(k);
					
					String roleName = role.getString("roleName");
					roleNames.add(roleName);
				}
				}
			}
			System.out.println("Role Names: " + roleNames);
	}
		}

		// // Get the tasks array
		// JSONArray tasks = jsonObject.getJSONArray("tasks");
		//
		// // Iterate through the tasks
		// for (int i = 0; i < tasks.length(); i++) {
		// JSONObject task = tasks.getJSONObject(i);
		//
		// // Get the assignees array from the task
		// JSONArray subtasks = task.getJSONArray("subtasks");
		//
		//
		// // Iterate through the roles and extract roleName
		// for (int k = 0; k < subtasks.length(); k++) {
		// JSONObject roleObject = subtasks.getJSONObject(k);
		// String roleName = roleObject.getString("dueDate");
		// roleNames.add(roleName);
		// }
		//
		// }

		// Print the extracted roleNames
		// System.out.println("Role Names: " + roleNames);
		// }
}
