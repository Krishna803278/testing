package api.endpoint;

import static io.restassured.RestAssured.given;

import api.payload.User;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UserEndPoints {

	// create user
	public static Response createUser(User payload){
	Response response=	given()
            .contentType(ContentType.JSON)
            .accept(ContentType.JSON)
            .body(payload)
        .when()
          .post(Routes.post_user_url);
	
	return response;
	}

	// get user
	public static Response readUser(String username) {
		Response response = given().pathParam("username", username) // Correct parameter name is "username"
			.when().get(Routes.get_user_url);
		return response;
	}

	// update user
	public static Response updateUser(String username, User payload) {
		Response response = given().pathParam("username", username).contentType(ContentType.JSON)
			.accept(ContentType.JSON).body(payload).when().put(Routes.update_user_url);
		return response;
	}

	// delete user
	public static Response deleteUser(String username) {
		Response response = given().pathParam("username", username).when().get(Routes.delet_user_url);
		return response;
	}
}
