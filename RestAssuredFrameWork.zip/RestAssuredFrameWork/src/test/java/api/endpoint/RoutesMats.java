package api.endpoint;


public class RoutesMats {

	public static String base_url = "https://matsapi.mouritech.net/mats/job/comments";

	// User Model
	public static String post_comment_url = base_url + "/saveComment";

	public static String update_updatebyCommentId_url = base_url + "/updatebyCommentId/{jobId}/{commentId}";

	public static String getAll_comments_url = base_url + "/getAllComments";

	public static String get_comment_url = base_url + "/comments-by/{JobId}";

	public static String delet_deletebyCommentId_url = base_url + "/deletebyCommentId/{commentId}";
}
