package api.endpoint;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ProjectApiTest {

	public static void main(String[] args) {
		  // Base URI of your API
        RestAssured.baseURI = "http://your-api-endpoint.com"; // Replace with your API endpoint

        // Send GET request to fetch project details
        Response response = RestAssured
            .given()
            .when()
            .get("/projects/PROJ123456") // Replace with your endpoint path
            .then()
            .statusCode(200)
            .extract()
            .response();

        // Extract the response body as a String
        String responseBody = response.getBody().asString();

        // Convert the response body to JSONObject
        JSONObject jsonResponse = new JSONObject(responseBody);

        // Extract tasks from the JSON object
        JSONArray tasks = jsonResponse.getJSONArray("tasks");

        // List to store role names
        List<String> roleNames = new ArrayList<>();

        // Iterate through tasks to find assignees with name "Alice Smith"
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject task = tasks.getJSONObject(i);
            JSONArray assignees = task.getJSONArray("assignees");

            for (int j = 0; j < assignees.length(); j++) {
                JSONObject assignee = assignees.getJSONObject(j);

                if (assignee.getString("name").equals("Alice Smith")) {
                    JSONArray roles = assignee.getJSONArray("roles");

                    // Extract role names
                    for (int k = 0; k < roles.length(); k++) {
                        JSONObject role = roles.getJSONObject(k);
                        roleNames.add(role.getString("roleName"));
                    }
                }
            }
        }

        // Print role names
        System.out.println("Role names for Alice Smith: " + roleNames);
    }
}
