package com.test;

import static io.restassured.RestAssured.given;

import java.util.List;

import org.testng.annotations.Test;

import com.test.poj.EvaluationData;

public class Day2 {
	
		
	
	 

 	@Test(priority = 2)
 	void createUser() {
 		
 		EvaluationData evaluationData = new EvaluationData();
 	     evaluationData.setStageStatusId(1);

 	     // Create and set skills
 	     EvaluationData.Skill skill = new EvaluationData.Skill();
 	     skill.setSkillName("Automationtesting");
 	     skill.setSkillDescription("bad");
 	     skill.setSkillRating("1.5");

 	     evaluationData.setSkills(List.of(skill));

 	     evaluationData.setComment("automationtesting");
 	     evaluationData.setOverallRecommendations("yes");
 	     evaluationData.setEvaluationFlag("not sure");
 	     
         given()
            .contentType("application/json")
            .body(evaluationData)
 		
 		.when()
 		   .post("http://localhost:8087/mats/resumeservice/evaluation/1268/2062")
 		   //.jsonPath().getInt("id");
 		.then()
 		     .statusCode(201)
 		     .log()
 			 .all();
 	}
	
	
	
	
	@Test(priority = 4)
	void DeleteUserById() {
		
		given()
		
		.when()
		   .delete("https://reqres.in/api/users/")
		.then()
		     .statusCode(204)
		     //.body("page", equalTo(2))
		     .log()
			 .all();
	}
}
