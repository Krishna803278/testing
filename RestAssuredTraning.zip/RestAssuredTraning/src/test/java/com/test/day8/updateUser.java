package com.test.day8;

import static io.restassured.RestAssured.given;

import java.util.HashMap;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.http.ContentType;

public class updateUser {
// **********  bearerToken  *************
	@Test()
	void updateUserById(ITestContext context) {
		Faker faker = new Faker();
		HashMap<String, String > date = new HashMap<>();
		date.put("name", faker.name().firstName());
		date.put( "gender", "male");
		date.put( "email", faker.internet().emailAddress());
		date.put( "status", "Active");
		
		//Long id=(Long) context.getAttribute("user_id");
		int id=5899509;
		String URL = "https://gorest.co.in/public/v2/users/{id}";
		String bearerToken = "ec9d94ee9d4b8f75d15ff87c5820a58bbae981d8725eaffc5ba310b446092ffd";

		  
		 
		 given()
		    .headers("Authorization", "Bearer " + bearerToken)
		    .contentType(ContentType.JSON)
		    .pathParam("id", id)
		    .body(date)
		.when()
		    .put(URL)
		.then()
		.statusCode(200).log().all();
		 

		
		
	}
}
