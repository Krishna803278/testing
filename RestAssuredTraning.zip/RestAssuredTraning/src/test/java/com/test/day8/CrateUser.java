package com.test.day8;

import static io.restassured.RestAssured.given;

import java.util.HashMap;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CrateUser {
// **********  bearerToken  *************
	@Test()
	void createUser(ITestContext context) {
	      Faker faker = new Faker();
	        HashMap<String, String> data = new HashMap<>();
	        data.put("name", faker.name().firstName());
	        data.put("gender", "male");
	        data.put("email", faker.internet().emailAddress());
	        data.put("status", "inActive");

	        String URL = "https://gorest.co.in/public/v2/users";
	        String bearerToken = "ec9d94ee9d4b8f75d15ff87c5820a58bbae981d8725eaffc5ba310b446092ffd";

	        Response response = given()
	                .headers("Authorization", "Bearer " + bearerToken)
	                .contentType(ContentType.JSON)
	                .body(data)
	                .when()
	                .post(URL);

	        if (response.getStatusCode() == 200) {
	            Long id = response.jsonPath().getLong("data.id");
	            if (id != null) {
	                System.out.println("Generated Id: " + id);
	                context.setAttribute("user_id", id);
	            } else {
	                System.out.println("Id not found in the response.");
	            }
	        } else {
	            System.out.println("Failed to create user. Status code: " + response.getStatusCode());
	            response.prettyPrint();
	        }
	    }
	}

