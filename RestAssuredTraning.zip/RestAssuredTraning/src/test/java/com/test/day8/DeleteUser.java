package com.test.day8;

import static io.restassured.RestAssured.given;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class DeleteUser {
// **********  bearerToken  *************
	@Test
	void DeleteUserById(ITestContext context) {

		
		//Long id=(Long) context.getAttribute("user_id");
		int id=5899509;
		String URL = "https://gorest.co.in/public/v2/users/{id}";
		String bearerToken = "ec9d94ee9d4b8f75d15ff87c5820a58bbae981d8725eaffc5ba310b446092ffd";
		
		 given()
		    .headers("Authorization", "Bearer " + bearerToken)
		    .contentType(ContentType.JSON)
		    .pathParam("id", id)
		   // .body(date)
		.when()
		    .delete(URL)
		.then()
		.statusCode(204).log().all();
		 

		
		
	}
}
