package com.test.poj;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Data
@Setter@Getter@NoArgsConstructor@AllArgsConstructor
public class Skill {
	
	   
	    
	        private String skillName;
	        private String skillDescription;
	        private String skillRating;

			
	    
	    
}
