package com.test.poj;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Data
@Setter@Getter@NoArgsConstructor@AllArgsConstructor
public class EvaluationData {
	
	   private int stageStatusId;
	    private List<Skill> skills;
	    private String comment;
	    private String overallRecommendations;
	    private String evaluationFlag;

		/*
		 * // Getters and Setters public int getStageStatusId() { return stageStatusId; } public void
		 * setStageStatusId(int stageStatusId) { this.stageStatusId = stageStatusId; } public List<Skill> getSkills() {
		 * return skills; } public void setSkills(List<Skill> skills) { this.skills = skills; } public String
		 * getComment() { return comment; } public void setComment(String comment) { this.comment = comment; } public
		 * String getOverallRecommendations() { return overallRecommendations; } public void
		 * setOverallRecommendations(String overallRecommendations) { this.overallRecommendations =
		 * overallRecommendations; } public String getEvaluationFlag() { return evaluationFlag; } public void
		 * setEvaluationFlag(String evaluationFlag) { this.evaluationFlag = evaluationFlag; }
		 */

	    // Skill class within EvaluationData
	    @Data
	    @Setter@Getter@NoArgsConstructor@AllArgsConstructor
	    public static class Skill {
	        private String skillName;
	        private String skillDescription;
	        private String skillRating;

			/*
			 * // Getters and Setters public String getSkillName() { return skillName; } public void setSkillName(String
			 * skillName) { this.skillName = skillName; } public String getSkillDescription() { return skillDescription;
			 * } public void setSkillDescription(String skillDescription) { this.skillDescription = skillDescription; }
			 * public String getSkillRating() { return skillRating; } public void setSkillRating(String skillRating) {
			 * this.skillRating = skillRating; }
			 */
	    }
	    
}
