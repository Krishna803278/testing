package com.test.day7;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

public class Day7 {
// **********  bearerToken  *************
	@Test(priority = 1)
	void createUser() {
		String URL = "";
		String bearerToken = "";
		given()
		  .headers("Autorization", "Beare " + bearerToken)
		  .contentType("application/json")
		.when()
		  .get(URL)
		.then()
		  .statusCode(200).log().all();
	}
// **********  oauth  *************
	@Test(priority = 2)
	void oauth() {
		String URL = "";
		
		given()
		     .auth().oauth("consumerKay", "consumerSecrat" ,"accessToken","tokenSecrate" )
		     .contentType("application/json")
		.when()
		      .get(URL)
		.then()
		      .statusCode(200).log().all();
	}
	// **********  oauth2  *************
		@Test(priority = 3)
		void oauth2() {
			String URL = "";
			
			given()
			     .auth().oauth2("")
			     .contentType("application/json")
			.when()
			      .get(URL)
			.then()
			      .statusCode(200).log().all();
		}
}
