package com.OIM.testbase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import io.appium.java_client.windows.WindowsDriver;

public class testbase {

	public static Properties prop;

	public static WebDriver driver;

	public static String driverPath;

	// public static WindowsDriver Sqldriver = null;
	public static WebElement SqlResult = null;

	public static Connection con = null;

	public static void init() {
		try {
			FileInputStream ip = new FileInputStream(
				System.getProperty("user.dir") + "/src/main/java/com/OIM/" + "config/config.properties");
			prop = new Properties();
			prop.load(ip);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void OIM_initialization() {
		String browserName = prop.getProperty("browser");
		System.out.println("browserName  ::" + browserName);
		/*
		 * driver = WebDriverManager.chromedriver().create(); //driver = WebDriverManager.chromedriver().getWebDriver();
		 * driver = new ChromeDriver()
		 */;
		if (browserName.equals("chrome")) {
			driverPath = System.getProperty("user.dir") + "\\resources\\drivers\\" + "chromedriver119.exe";
			/// C:\Users\V002HS\git\ccbbusinessprocess\resources\drivers
			System.setProperty("webdriver.chrome.driver", driverPath);
			System.out.println(driverPath);
			driver = new ChromeDriver();
		} else if (browserName.equals("FF")) {
			System.setProperty("webdriver.gecko.driver", "/Users/Documents/SeleniumServer/geckodriver");
			driver = new FirefoxDriver();
		}
		driver.manage().window().maximize();
		// driver.manage().deleteAllCookies();
		System.out.println("browserName" + prop.getProperty("OIM_URL"));
		driver.get(prop.getProperty("OIM_URL"));
		// System.out.println("data is "+data);
	}

	public String getScreenshot() {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String path = System.getProperty("user.dir") + "/screenshots/" + System.currentTimeMillis() + ".png";
		File destination = new File(path);
		try {
			FileUtils.copyFile(src, destination);
		} catch (IOException e) {
			System.out.println("Capture Failed " + e.getMessage());
		}
		return path;
	}
}
