package com.tesng.groups;

import org.testng.annotations.Test;

public class MyTest {


	@Test
	public void InitialiseBrowser() {
		System.err.println("InitialiseBrowser");
	}


	@Test
	public void lunchApp() {
		System.err.println("lunchApp");
	}

	@Test
	public void getTitle() {
		System.err.println("getTitle");

	}

	@Test
	public void goBucketPage() {
		System.err.println("goBucketPage");
	}

	@Test
	public void goSearch() {
		System.err.println("goSearch");

	}
}
