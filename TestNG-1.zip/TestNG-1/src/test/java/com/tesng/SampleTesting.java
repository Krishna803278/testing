package com.tesng;


public class SampleTesting {
}
