package com.shopdemo.st;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StandAlone {

	public static void main(String[] args) throws InterruptedException {
		String productName = "Computing and Internet";
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		driver.get("https://demowebshop.tricentis.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//a[.='Log in']")).click();
		driver.findElement(By.id("Email")).sendKeys("bkreddy1316@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Test@123");
		driver.findElement(By.xpath("//input[@value='Log in']")).click();
		String accountName =
			driver.findElement(By.cssSelector("div[class='header-links'] a[class='account']")).getText();
		System.out.println(accountName);
		driver.findElement(By.xpath("(//a[normalize-space()='Books'])[1]")).click();
		List<WebElement> books = driver.findElements(By.xpath("//div[@class='product-item']"));
		books.forEach(book -> {
			String bookName = book.findElement(By.xpath(".//h2/a")).getText();
			System.out.println("Product Name: " + bookName);
			if (bookName.equals(productName)) {
				book.findElement(By.xpath(".//input[@type='button']")).click();
			}
		});
	}
}
