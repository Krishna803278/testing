package com.module;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class user {

	private int userId;

	private UserDetails userDetails;

	private Preferences preferences;

	private String accountStatus;

	private String creationDate;
}
