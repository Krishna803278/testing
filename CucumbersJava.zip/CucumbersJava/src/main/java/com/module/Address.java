package com.module;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Address {

	public String street;

	public String city;

	public String state;

	public String zipCode;

	public String country;
}
