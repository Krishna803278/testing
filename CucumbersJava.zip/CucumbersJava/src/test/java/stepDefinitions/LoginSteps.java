package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginSteps {

	WebDriver driver;

	@Given("the user is on the login page")
	public void the_user_is_on_the_login_page() {
		// Set the path for the ChromeDriver
		WebDriverManager.chromedriver().setup();
		// Initialize the WebDriver and open the login page
		driver = new ChromeDriver();
		driver.get("https://www.example.com/login");
	}

	@When("the user enters a valid username and password")
	public void the_user_enters_a_valid_username_and_password() {
		// Enter valid username and password
		driver.findElement(By.id("username")).sendKeys("validUsername");
		driver.findElement(By.id("password")).sendKeys("validPassword");
	}

	@When("the user enters an invalid username and password")
	public void the_user_enters_an_invalid_username_and_password() {
		// Enter invalid username and password
		driver.findElement(By.id("username")).sendKeys("invalidUsername");
		driver.findElement(By.id("password")).sendKeys("invalidPassword");
	}

	@When("the user clicks the login button")
	public void the_user_clicks_the_login_button() {
		// Click the login button
		driver.findElement(By.id("loginButton")).click();
	}

	@Then("the user should be redirected to the homepage")
	public void the_user_should_be_redirected_to_the_homepage() {
		// Verify that the user is redirected to the homepage
		String expectedUrl = "https://www.example.com/home";
		String actualUrl = driver.getCurrentUrl();
		if (!expectedUrl.equals(actualUrl)) {
			throw new AssertionError("User is not redirected to the homepage");
		}
		// Close the browser
		driver.quit();
	}

	@Then("the user should see an error message")
	public void the_user_should_see_an_error_message() {
		// Verify that an error message is displayed
		String expectedErrorMessage = "Invalid username or password";
		String actualErrorMessage = driver.findElement(By.id("errorMessage")).getText();
		if (!expectedErrorMessage.equals(actualErrorMessage)) {
			throw new AssertionError("Error message not displayed as expected");
		}
		// Close the browser
		driver.quit();
	}
}
