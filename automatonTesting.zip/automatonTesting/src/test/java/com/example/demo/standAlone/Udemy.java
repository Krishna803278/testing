package com.example.demo.standAlone;

import java.io.IOException;

import org.testng.annotations.Test;

import com.example.demo.testcomponent.BaseTest;

public class Udemy extends BaseTest {

	@Test
	public void mainmethod() throws IOException, InterruptedException {
		// WebDriverManager.edgedriver().setup();
		// WebDriver driver = new EdgeDriver();
		// driver.get("https://www.overleaf.com/login");
		// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
		// driver.manage().window().maximize();
		// System.out.println("Page Titile" + driver.getTitle());
		// driver.findElement(By.id("email")).sendKeys("bkreddy1316@gmail.com");
		// driver.findElement(By.id("password")).sendKeys("Kri@(1998)r");
		// WebElement submit = driver.findElement(By.xpath("//div[@class='actions']//button[@type='submit']"));
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		// js.executeScript("arguments[0].scrollIntoView(true);", submit);
		// submit.click();
		LandingPage landingPage = launchApp();
		// System.out.println("Page Titile" + driver.getTitle());
		landingPage.credentional("bkreddy1316@gmail.com", "Kri@(1998)r");
		Thread.sleep(2000);
		landingPage.accMenu();
	}
}
