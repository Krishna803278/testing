package com.example.demo.dataprovider;

import org.testng.annotations.Test;

@Test
public class DataProvider2 {

	@Test(dataProvider = "loginTest", dataProviderClass = DataProviderExtranlClass.class)
	public void testLogin(String username, String password) {
		System.err.println("username :- " + username + " -- " + "password :- " + password);
	}

	@Test(dataProvider = "integer", dataProviderClass = DataProviderExtranlClass.class)
	public void testcase(Integer valve) {
		System.err.println("numbers :- " + valve);
	}

	@Test(dataProvider = "indices", dataProviderClass = DataProviderExtranlClass.class)
	public void testcase1(Object valve) {
		System.err.println("valve :- " + valve);
	}
}
