package com.example.demo.parallel;

import org.testng.annotations.Test;

@Test
public class Parallel {

	@Test
	public void testMethod1() {
		System.out.println("TestClass1 - testMethod1 - " + Thread.currentThread().getId());
	}

	public class TestClass2 {

		@Test
		public void testMethod2() {
			System.out.println("TestClass2 - testMethod2 - " + Thread.currentThread().getId());
		}
	}

	public class TestClass3 {

		@Test
		public void testMethod3() {
			System.out.println("TestClass3 - testMethod3 - " + Thread.currentThread().getId());
		}
	}
}
