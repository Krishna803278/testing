package com.example.demo.standAlone;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandingPage extends Abstract {

	WebDriver driver;
	// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));

	public LandingPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "email")
	WebElement UserEmail;

	@FindBy(id = "password")
	WebElement UserPassword;

	@FindBy(id = "arguments[0].scrollIntoView(true)") // Assuming the cookie banner has an ID
	private WebElement cookieBanner;

	@FindBy(xpath = "//div[@class='actions']//button[@type='submit']")
	WebElement login;

	@FindBy(xpath = "//li[@class = 'dropdown open']")
	WebElement accountMenu;

	@FindBy(xpath = "//button[contains(@class,'text-left')]")
	WebElement logOut;

	public void credentional(String email, String password) {
		UserEmail.sendKeys(email);
		UserPassword.sendKeys(password);
		scrollToElement(login);
		login.click();
	}

	public void goTo() {
		driver.get("https://www.overleaf.com/login");
		// driver.manage().window().maximize();
	}

	private void scrollToElement(WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void accMenu() {
		waitElementToAppeare(By.xpath("//li[@class = 'dropdown open']"));
		accountMenu.click();
		logOut.clear();
	}
}
