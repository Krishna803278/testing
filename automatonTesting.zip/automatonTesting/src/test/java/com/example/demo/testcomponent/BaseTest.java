package com.example.demo.testcomponent;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.example.demo.standAlone.LandingPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {

	WebDriver driver;

	LandingPage landingPage;

	public WebDriver initializeddriver() throws IOException {
		Properties properties = new Properties();
		FileInputStream file = new FileInputStream(
			System.getProperty("user.dir") + "\\src\\test\\java\\com\\example\\demo\\resources\\GlobleData.properties");
		properties.load(file);
		String browserName = properties.getProperty("browser");
		if (browserName.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		if (browserName.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		if (browserName.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new EdgeDriver();
		}
		driver.manage().window().maximize();
		return driver;
	}

	public LandingPage launchApp() throws IOException {
		driver = initializeddriver();
		landingPage = new LandingPage(driver);
		landingPage.goTo();
		return landingPage;
	}
}
