package com.example.demo.dataprovider;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class DataProviderExtranlClass {

	@DataProvider(name = "loginTestData")
	public Object[][] provideLoginData() {
		return new Object[][] {{"user1", "password1"}, {"user2", "password2"}, {"user3", "password3"},
			{"user4", "password4"}};
	}

	@DataProvider(name = "loginTest")
	public Object[][] provideLoginDat() {
		return new Object[][] {{"1", "2"}, {"3", "4"}, {"5", "6"}, {"7", "8"}};
	}

	@DataProvider(name = "integer")
	public Integer[] data() {
		return new Integer[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
	}

	@DataProvider(name = "indices", indices = {0, 3})
	public Object[] data1() {
		return new Object[] {"a", "b", "c", "d"};
	}
}
