package com.example.demo.screenshot;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class MainCode extends BaseTest {
	// WebDriver driver;

	@Test
	public void launchApp() {
		if (driver == null) {
			System.out.println("Driver is null. Initialize it in BaseTest class.");
			return;
		}
		driver.get("https://www.overleaf.com/");
		driver.findElement(By.xpath("//a[normalize-space()='Sign up']")).click();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("bkreddy1316@gmail.com");
		driver.findElement(By.xpath("//input[@id='passwordField']")).sendKeys("Kri@(1998)r");
		driver.findElement(By.xpath("//div[@class='actions']")).click();
	}

	@Test
	public void launchAppfaile() {
		if (driver == null) {
			System.out.println("Driver is null. Initialize it in BaseTest class.");
			return;
		}
		driver.get("https://www.overleaf.com/");
		driver.findElement(By.xpath("//a[normalize-space()='Sign up']")).click();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("bkreddy1316@gmail.com");
		driver.findElement(By.xpath("//input[@id='passwordField']")).sendKeys("Kri@(1998");
		driver.findElement(By.xpath("//div[@class='actions']")).click();
	}
}
