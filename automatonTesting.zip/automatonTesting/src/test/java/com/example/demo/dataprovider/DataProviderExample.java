package com.example.demo.dataprovider;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@Test
public class DataProviderExample {

	WebDriver driver;

	@Test(dataProvider = "loginTestData")
	public void testLogin(String username, String password) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
		driver
			.findElement(
				By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button']"))
			.click();
		System.err.println("Paze Titile :- " + driver.getTitle());
		driver.findElement(By.xpath("//p[@class='oxd-userdropdown-name']")).click();
		driver.findElement(By.linkText("Logout")).click();
		Thread.sleep(2000);
	}

	@DataProvider(name = "loginTestData")
	public Object[][] provideLoginData() {
		return new Object[][] {{"user1", "password1"}, {"user2", "password2"}, {"user3", "password3"},
			{"Admin", "admin123"}};
	}
}
