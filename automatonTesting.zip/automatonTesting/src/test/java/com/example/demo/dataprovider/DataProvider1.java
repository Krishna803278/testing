package com.example.demo.dataprovider;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@Test
public class DataProvider1 {

	@Test(dataProvider = "loginTestData")
	public void testLogin(String username, String password) {
		System.err.println("username" + username + " -- " + "password" + password);
	}

	@DataProvider(name = "loginTestData")
	public Object[][] provideLoginData() {
		return new Object[][] {{"user1", "password1"}, {"user2", "password2"}, {"user3", "password3"},
			{"user4", "password4"}};
	}
}
