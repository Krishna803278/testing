package com.example.demo.problems;

import java.util.LinkedHashMap;
import java.util.Map;

public class MinOccurrenceFinder {

	public static void main(String[] args) {
		String str = "abcdddderfa";
		char maxChar = findMaxOccurrence(str);
		System.out.println("Character with maximum occurrence: '" + maxChar + "'");
	}

	public static char findMaxOccurrence(String str) {
		Map<Character, Integer> charOccurrences = new LinkedHashMap<>();
		for (char ch : str.toCharArray()) {
			charOccurrences.put(ch, charOccurrences.getOrDefault(ch, 0) + 1);
		}
		char maxChar = '\0'; // Initialize with null character
		// int maxCount = 0;
		int minCount = Integer.MAX_VALUE;
		for (Map.Entry<Character, Integer> entry : charOccurrences.entrySet()) {
			if (entry.getValue() < minCount) {
				minCount = entry.getValue();
				maxChar = entry.getKey();
			}
		}
		return maxChar;
	}
}
