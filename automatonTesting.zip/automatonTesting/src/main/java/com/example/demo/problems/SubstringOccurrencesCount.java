package com.example.demo.problems;

public class SubstringOccurrencesCount {

	public static void main(String[] args) {
		String inputString = "Java is a widely used programming language. Java is versatile and has a large community.";
		String substring = "Java";
		int count = countSpecificWordOccurrences(inputString, substring);
		System.out.println("Number of occurrences of \"" + substring + "\": " + count);
	}

	public static int countSpecificWordOccurrences(String str, String wordToCount) {
		int count = 0;
		for (String word : str.split("\\s+")) {
			if (word.equals(wordToCount)) {
				count++;
			}
		}
		return count;
	}
}
