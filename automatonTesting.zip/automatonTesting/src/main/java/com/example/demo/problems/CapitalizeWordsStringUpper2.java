package com.example.demo.problems;

public class CapitalizeWordsStringUpper2 {

	public static void main(String[] args) {
		String str = "hello@world#java0program9am";
		String processedStr = processString(str);
		System.out.println(processedStr);
	}

	public static String processString(String str) {
		String[] words = str.split("[^a-zA-Z]+");// "(?=[A-Z])")
		StringBuilder capitalizedStr = new StringBuilder();
		for (String word : words) {
			if (word.length() > 0) {
				// Capitalize the first letter and append the rest of the word in lowercase
				capitalizedStr//
					.append(Character.toUpperCase(word.charAt(0)))//
					.append(word.substring(1).toLowerCase())//
					.append(" ");
			}
		}
		return capitalizedStr.toString().trim();
	}
}
