package com.example.demo.problems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WordOccurrencesDuplicateWordsAddINList2 {

	public static void main(String[] args) {
		String str = "hello a java world a java program";
		//
		Map<Character, Integer> charCount = new HashMap<>();
		List<Character> duplicates = new ArrayList<>();
		List<Character> uniques = new ArrayList<>();
		//
		for (char ch : str.toCharArray()) {
			charCount.put(ch, charCount.getOrDefault(ch, 0) + 1);
		}
		for (Map.Entry<Character, Integer> entry : charCount.entrySet()) {
			if (entry.getValue() > 1) {
				duplicates.add(entry.getKey());
			} else {
				uniques.add(entry.getKey());
			}
		}
		System.out.println("Duplicate characters: " + duplicates);
		System.out.println("Unique characters: " + uniques);
	}
}
