package com.example.demo.problems;

public class SubstringOccurrencesCount2 {

	public static void main(String[] args) {
		String inputString = "Javaisawidelyusedprogramming";
		char substring = 'g';
		int count = countSpecificCharacterOccurrences(inputString, substring); // Renamed method for clarity
		System.out.println("Number of occurrences of \"" + substring + "\": " + count);
	}

	public static int countSpecificCharacterOccurrences(String str, char charToCount) {
		int count = 0;
		for (char c : str.toCharArray()) {
			if (c == charToCount) {
				count++;
			}
		}
		return count;
	}
}
