package com.example.demo.problems.numbers;

import java.util.Scanner;
import java.util.stream.IntStream;

public class ArmstrongNumber {
	// Examples Armstrong number
	// 153, 370, 371, 407, 1634, 8208, 9474, 54748, 92727, 93084

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.err.println("enter The Number :- ");
		int number = scanner.nextInt();
		IntStream.rangeClosed(2, number).filter(ArmstrongNumber::isArmstrong).forEach(System.out::println);
		// if (isArmstrong(number)) {
		// System.out.println(number + " is an Armstrong number.");
		// } else {
		// System.out.println(number + " is not an Armstrong number.");
		// }
		scanner.close();
	}

	public static Boolean isArmstrong(int number) {
		int numdigit = String.valueOf(number).length();
		int num =
			String.valueOf(number).chars().map(Character::getNumericValue).map(d -> (int) Math.pow(d, numdigit)).sum();
		return num == number;
	}
}
