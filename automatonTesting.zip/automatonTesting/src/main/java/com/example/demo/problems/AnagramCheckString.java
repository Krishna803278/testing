package com.example.demo.problems;

import java.util.Arrays;

public class AnagramCheckString {

	public static void main(String[] args) {
		String num = "listen";
		String num2 = "silent";
		if (checkNumberAnagram(num, num2)) {
			System.out.println(num + " and " + num2 + " are anagrams.");
		} else {
			System.out.println(num + " and " + num2 + " are not anagrams.");
		}
	}

	public static Boolean checkNumberAnagram(String input1, String input2) {
		// String str = String.valueOf(input1);
		// String str2 = String.valueOf(input2);
		char[] char1 = input1.toCharArray();
		char[] char2 = input2.toCharArray();
		Arrays.sort(char1);
		Arrays.sort(char2);
		return Arrays.equals(char1, char2);
	}
}
