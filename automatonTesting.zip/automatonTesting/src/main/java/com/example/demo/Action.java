package com.example.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Action {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get(
			"https://www.amazon.in/?tag=msndeskabkin-21&ref=pd_sl_7qhce485bd_e&adgrpid=1322714095756137&hvadid=82669897710514&hvnetw=o&hvqmt=e&hvbmt=be&hvdev=c&hvlocint=&hvlocphy=144064&hvtargid=kwd-82670512756912:loc-90&hydadcr=14453_2334184");
		WebElement ele = driver.findElement(By.xpath("(//div[@class='nav-line-1-container'])[1]"));
		Actions ac = new Actions(driver);
		ac.moveToElement(ele).perform();
		Thread.sleep(5000);
		ac.moveToElement(driver.findElement(By.id("twotabsearchtextbox"))).click().keyDown(Keys.SHIFT)
			.sendKeys("iphone").doubleClick().perform();
		Thread.sleep(5000);
	}
}
