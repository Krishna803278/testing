package com.example.demo;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Action2 {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://bestvpn.org/html5demos/drag/");
		driver.manage().window().maximize();
		WebElement src = driver.findElement(By.id("one"));
		WebElement src1 = driver.findElement(By.id("four"));
		WebElement trg = driver.findElement(By.id("bin"));
		Actions ac = new Actions(driver);
		ac.dragAndDrop(src, trg).perform();
		ac.dragAndDrop(src1, trg).perform();
		Thread.sleep(5000);
		WebElement move = driver.findElement(By.xpath("//*[*='Reviews']"));
		WebElement move1 = driver.findElement(By.xpath("//a[normalize-space()='ProtonVPN Review']"));
		ac.moveToElement(move).moveToElement(move1).click().perform();
		WebElement footer = driver.findElement(By.xpath("//*[@class='footer__row']"));
		int links = footer.findElements(By.tagName("a")).size();
		for (int i = 0; i < links; i++) {
			String sendKey = Keys.chord(Keys.CONTROL, Keys.ENTER);
			footer.findElements(By.tagName("a")).get(i).sendKeys(sendKey);
			Thread.sleep(5000);
		}
		Set<String> windows = driver.getWindowHandles();
		windows.stream().forEach(x -> {
			driver.switchTo().window(x);
			System.out.println(driver.getTitle());
		});
	}
}
