package com.example.demo.problems;

public class CapitalizeLastWordUpper {

	public static void main(String[] args) {
		String str = "hello world java program";
		String capitalizedStr = capitalizeWords(str);
		System.out.println("oldString - " + str);
		System.out.println("capitalizedStr - " + capitalizedStr);
	}

	public static String capitalizeWords(String str) {
		StringBuilder capitalizedStr = new StringBuilder();
		String[] words = str.split("\\s+");
		for (String word : words) {
			if (word.length() > 0) {
				// Append the word except the last character in original case
				capitalizedStr//
					.append(word, 0, word.length() - 1)//
					.append(Character.toUpperCase(word.charAt(word.length() - 1)))//
					.append(" ");
			}
		}
		return capitalizedStr.toString().trim();
	}
}
