package com.example.demo.problems;

public class CapitalizeWordsStringUpper {

	public static void main(String[] args) {
		String str = "hello world java program";
		String capitalizedStr = capitalizeWords(str);
		System.out.println("oldString - " + str);
		System.out.println("capitalizedStr - " + capitalizedStr);
	}

	public static String capitalizeWords(String str) {
		StringBuilder capitalizedStr = new StringBuilder();
		String[] words = str.split("\\s+");
		for (String word : words) {
			if (word.length() > 0) {
				capitalizedStr//
					.append(Character.toUpperCase(word.charAt(0)))//
					.append(word.substring(1).toLowerCase())//
					.append(" ");
			}
		}
		return capitalizedStr.toString().trim();
	}
}
