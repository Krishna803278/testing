package com.example.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDownsAutoLocation {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://twoplugs.com/");
		driver.findElement(By.xpath("//li/a[.='Live Posting']")).click();
		WebElement searchBox = driver.findElement(By.id("autocomplete"));
		searchBox.clear();
		searchBox.sendKeys("hyd");
		Thread.sleep(1000);
		String text;
		do {
			searchBox.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(1000);
			text = searchBox.getAttribute("value");
			if (text.equals("Hydra, Algeria")) {
				searchBox.sendKeys(Keys.ENTER);
				break;
			}
			Thread.sleep(1000);
		} while (!text.isEmpty());
	}
}
