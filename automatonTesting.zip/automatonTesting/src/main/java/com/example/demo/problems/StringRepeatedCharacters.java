package com.example.demo.problems;

public class StringRepeatedCharacters {

	public static void main(String[] args) {
		String str1 = "Hello";
		String str2 = "Jevall";
		String repeatedChars = getRepeatedCharacters(str1, str2);
		System.out.println("Repeated characters: " + repeatedChars);
	}

	public static String getRepeatedCharacters(String str1, String str2) {
		StringBuilder result = new StringBuilder();
		for (char ch1 : str1.toCharArray()) {
			for (char ch2 : str2.toCharArray()) {
				if (ch1 == ch2 && (result.indexOf(String.valueOf(ch1)) == -1)) {
					result.append(ch1);
				}
			}
		}
		return result.toString();
	}
}
