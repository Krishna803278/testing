package com.example.demo.problems.numbers;

import java.util.ArrayList;
import java.util.List;

public class evenNumberCount2 {

	public static void main(String[] args) {
		// Input list of numbers
		List<Integer> numbers = List.of(5, 12, 7, 20, 33, 44, 68, 75, 89, 90, 21, 22);
		int evenCount = 0;
		int oddCount = 0;
		List<Integer> evenNumbers = new ArrayList<>();
		List<Integer> oddNumbers = new ArrayList<>();
		for (int number : numbers) {
			if (number % 2 == 0) {
				evenCount++;
				evenNumbers.add(number);
			} else {
				oddCount++;
				oddNumbers.add(number);
			}
		}
		System.out.println("Number of even Count: " + evenCount);
		System.out.println("Number of odd Count: " + oddCount);
		System.out.println("Even numbers: " + evenNumbers);
		System.out.println("Odd numbers: " + oddNumbers);
	}
}
