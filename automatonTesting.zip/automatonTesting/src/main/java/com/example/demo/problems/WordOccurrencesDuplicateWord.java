package com.example.demo.problems;

import java.util.LinkedHashMap;
import java.util.Map;

public class WordOccurrencesDuplicateWord {

	public static void main(String[] args) {
		String str = "Java is a programming language and Java is also a platform";
		Map<String, Integer> charOccurrences = countCharacterOccurrences(str);
		for (Map.Entry<String, Integer> entry : charOccurrences.entrySet()) {
			if (entry.getValue() > 1) {
				System.out.println("'" + entry.getKey() + "' : " + entry.getValue());
			}
		}
	}

	public static Map<String, Integer> countCharacterOccurrences(String str) {
		Map<String, Integer> charOccurrences = new LinkedHashMap<>();
		String[] words = str.split(" ");
		for (String word : words) {
			charOccurrences.put(word, charOccurrences.getOrDefault(word, 0) + 1);
		}
		return charOccurrences;
	}
}
