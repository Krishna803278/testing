package com.example.demo.problems.numbers;

import java.util.Scanner;

public class SumOfNaturalNumbersIterative {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a positive integer: ");
		int n = scanner.nextInt();
		scanner.close();
		int sum = 0;
		// for (int i = 2; i <= n; i++) {
		// if (isPrime(i)) {
		// sum += i;
		// }
		// }
		// The sum of even numbers up to
		// for (int i = 2; i <= n; i += 2) {
		// sum += i;
		// }
		// The sum of odd numbers up to
		for (int i = 1; i <= n; i += 2) {
			sum += i;
		}
		// }
		// for (int i = 1; i <= n; i++) {
		// sum += i;
		// }
		System.out.println("The sum of natural numbers up to " + n + " is: " + sum);
	}
}
