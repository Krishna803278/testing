package com.example.demo.problems.numbers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UniquePairs3 {

	// adding 2 element == 7 like [2, 5],[3, 4]
	public static List<int[]> findUniquePairs(int[] arr, int value) {
		Arrays.sort(arr);
		int left = 0;
		int right = arr.length - 1;
		List<int[]> result = new ArrayList<>();
		while (left < right) {
			int sum = arr[left] + arr[right];
			if (sum == value) {
				result.add(new int[] {arr[left], arr[right]});
				left++;
				right--;
			} else if (sum < value) {
				left++;
			} else {
				right--;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		// adding 2 element == 7 like [2, 5],[3, 4]
		int[] arr = {4, 3, 10, 8, 2, 6, 5};
		int value = 7;
		List<int[]> output = findUniquePairs(arr, value);
		System.out.println("Output:");
		for (int[] pair : output) {
			System.out.println(Arrays.toString(pair));
		}
	}
}
