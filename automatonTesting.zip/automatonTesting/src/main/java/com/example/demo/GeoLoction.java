package com.example.demo;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GeoLoction {

	public static void main(String[] args) throws InterruptedException {
		EdgeOptions options = new EdgeOptions();
		options.addArguments("--disable-notifications");
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver(options);
		driver.get("https://www.redbus.in/");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement searchInput =
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@type='text'])[1]")));
		searchInput.sendKeys("Hyd");
		Thread.sleep(2000);
		// driver.findElement(By.xpath("//div[contains(@class ,'kWSbju')]")).sendKeys("Hyd");
		List<WebElement> listElement2 = driver.findElements(By.xpath("//ul[contains(@class ,'eFEVtU')]//li"));
		System.out.println(listElement2.size());
		multiSelectMethod(listElement2, "Hyderabad");
	}

	public static void multiSelectMethod(List<WebElement> elements, String valve) {
		for (WebElement webElement : elements) {
			if (webElement.getText().equalsIgnoreCase(valve)) {
				webElement.click();
				break;
			}
		}
	}
}
