package com.example.demo;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class standAlneappilication {

	public static void main(String[] args) throws InterruptedException {
		String prodectName = "ADIDAS ORIGINAL";
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.get("https://rahulshettyacademy.com/client");
		driver.manage().window().maximize();
		driver.findElement(By.id("userEmail")).sendKeys("zxy12@gmail.com");
		driver.findElement(By.id("userPassword")).sendKeys("Abc@1234");
		driver.findElement(By.id("login")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".mb-3")));
		List<WebElement> prodects = driver.findElements(By.cssSelector(".mb-3"));
		WebElement prod = prodects.stream()
			.filter(x -> x.findElement(By.cssSelector("b")).getText().equals(prodectName)).findFirst().orElse(null);
		prod.findElement(By.cssSelector(".card-body button:last-child")).click();
		wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.id("toast-container"))));
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@routerlink='/dashboard/cart']")).click();
		List<WebElement> cardProdects = driver.findElements(By.cssSelector(".infoWrap h3"));
		Boolean match = cardProdects.stream().anyMatch(x -> x.getText().equalsIgnoreCase(prodectName));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Checkout']")));
		driver.findElement(By.xpath("//button[normalize-space()='Checkout']")).click();
		// wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//div[@class='form-group']"))));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Select Country']")));
		WebElement serchBox = driver.findElement(By.xpath("//input[@placeholder='Select Country']"));
		serchBox.sendKeys("ind");
		// Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='button']//span")));
		List<WebElement> serchBox1 = driver.findElements(By.xpath("//button[@type='button']//span"));
		multiSelectMethod(serchBox1, "India");
		driver.findElement(By.cssSelector(".btnn")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".hero-primary")));
		String str = driver.findElement(By.cssSelector(".hero-primary")).getText();
		assertEquals(str, "THANKYOU FOR THE ORDER.");
		System.err.println(str);
	}

	public static void multiSelectMethod(List<WebElement> elements, String valve) {
		for (WebElement webElement : elements) {
			if (webElement.getText().equals(valve)) {
				webElement.click();
				break;
			}
		}
	}
}
