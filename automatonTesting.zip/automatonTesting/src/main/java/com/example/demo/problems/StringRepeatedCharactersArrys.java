package com.example.demo.problems;

import java.util.HashSet;
import java.util.Set;

public class StringRepeatedCharactersArrys {

	public static void main(String[] args) {
		String[] array1 = {"Hello", "World"};
		String[] array2 = {"Jevall", "Holla"};
		String repeatedChars = getRepeatedCharacters(array1, array2);
		System.out.println("Repeated characters: " + repeatedChars);
	}

	public static String getRepeatedCharacters(String[] array1, String[] array2) {
		StringBuilder result = new StringBuilder();
		Set<Character> uniqueChars = new HashSet<>();
		for (String Str1 : array1) {
			for (String Str2 : array2) {
				for (char ch1 : Str1.toCharArray()) {
					for (char ch2 : Str2.toCharArray()) {
						if (ch1 == ch2 && !uniqueChars.contains(ch1)) {
							uniqueChars.add(ch1);
							result.append(ch1);
						}
					}
				}
			}
		}
		return result.toString();
	}
}
