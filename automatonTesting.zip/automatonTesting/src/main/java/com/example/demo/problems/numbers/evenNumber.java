package com.example.demo.problems.numbers;

import java.util.Scanner;

public class evenNumber {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number");
		int num = scanner.nextInt();
		if (num % 2 == 0) {
			System.err.println("even" + num);
		} else {
			System.err.println("odd" + num);
		}
	}
}
