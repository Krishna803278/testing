package com.example.demo.problems;

public class CapitalizeWordsStringUpper4 {

	public static void main(String[] args) {
		String str = "hello@world#java0program2am";
		String processedStr = processString(str);
		System.out.println(processedStr);
	}

	public static String processString(String str) {
		// Split the string by any non-letter character
		String[] words = str.split("[^a-zA-Z]+");
		StringBuilder capitalizedStr = new StringBuilder();
		for (String word : words) {
			if (word.length() > 0) {
				// Further split the word if it contains uppercase letters in the middle
				String[] subWords = word.split("(?=[A-Z])");
				for (String subWord : subWords) {
					if (subWord.length() > 0) {
						// Capitalize the first letter and append the rest of the word in lowercase
						capitalizedStr.append(Character.toUpperCase(subWord.charAt(0)))
							.append(subWord.substring(1).toLowerCase()).append("\n");
					}
				}
			}
		}
		return capitalizedStr.toString().trim();
	}
}
