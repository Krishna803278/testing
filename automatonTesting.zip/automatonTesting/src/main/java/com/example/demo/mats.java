package com.example.demo;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class mats {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(200));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofMinutes(1));
		driver.get("https://matsdev.mouritech.net/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[normalize-space()='Login with Microsoft 365']")).click();
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("matsdev@mouritech.org");
		driver.findElement(By.id("idSIButton9")).click();
		driver.findElement(By.id("i0118")).sendKeys("Mam34639");
		Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(
			By.xpath("//input[@class='win-button button_primary button ext-button primary ext-primary']")));
		driver
			.findElement(By.xpath("//input[@class='win-button button_primary button ext-button primary ext-primary']"))
			.click();
		driver.findElement(By.xpath("//input[@value='Yes']")).click();
		driver.findElement(By.xpath("//img[@aria-label='RRF']")).click();
		// WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.id("demo-customized-button")));
		// element.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("demo-customized-button")));
		driver.findElement(By.id("demo-customized-button")).click();
		System.out.println("TITLE : " + driver.getTitle());
		driver.findElement(By.xpath("//input[@name='rrfTitle']")).sendKeys("Java");
		//
		// Drop-Down
		driver.findElement(By.xpath("(//div[@role='button'])[1]")).click();
		List<WebElement> listElement = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
		System.out.println(listElement.size());
		multiSelectMethod(listElement, "Digital Transformation");
		//
		// Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@role='button'])[3]")));
		driver.findElement(By.xpath("(//div[@role='button'])[3]")).click();
		List<WebElement> l2 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l2, "Mobility");
		// Thread.sleep(1000);
		wait.until(ExpectedConditions
			.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Select Practice Head')])[1]")));
		driver.findElement(By.xpath("(//div[contains(text(),'Select Practice Head')])[1]")).click();
		List<WebElement> l3 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l3, "Siva Dega");
		// Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("mui-component-select-hrManager.userId")));
		driver.findElement(By.id("mui-component-select-hrManager.userId")).click();
		List<WebElement> l4 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l4, "Sailaja GUDALA");
		// Thread.sleep(1000);
		wait.until(
			ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'Select Client')])[1]")));
		driver.findElement(By.xpath("(//div[contains(text(),'Select Client')])[1]")).click();
		List<WebElement> l5 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l5, "abc");
		// Thread.sleep(1000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(":rv:")));
		driver.findElement(By.id(":rv:")).sendKeys("java");
		// Thread.sleep(1000);
		driver.findElement(By.id(":r11:")).sendKeys("https://matsqa.mouritech.net/createRRF?type=createRRF");
		// Thread.sleep(1000);
		driver.findElement(By.id(":r12:")).sendKeys("10");
		// driver.findElement(By.xpath("//input[@id=':r1l:']")).sendKeys("10");
		// Thread.sleep(1000);
		wait.until(
			ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Select Hire/Replace')]")));
		driver.findElement(By.xpath("//div[contains(text(),'Select Hire/Replace')]")).click();
		List<WebElement> l6 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l6, "New Hire");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[contains(text(),'Select Billable/Non Billable')]")).click();
		List<WebElement> l7 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l7, "Billable");
		Thread.sleep(2000);
		driver.findElement(By.xpath(
			"//div[@class='MuiInputBase-root MuiOutlinedInput-root MuiInputBase-colorPrimary Mui-error Mui-focused add__select css-bnwvx5']//div[contains(text(),'Set Priority')]"))
			.click();
		List<WebElement> l8 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l8, "High");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector(
			"body > div:nth-child(1) > main:nth-child(1) > div:nth-child(1) > main:nth-child(4) > form:nth-child(1) > div:nth-child(2) > div:nth-child(4) > div:nth-child(1) > div:nth-child(22) > div:nth-child(2)"))
			.click();
		List<WebElement> l9 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l9, "Support Functions");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id=':r1l:']")).sendKeys("10");
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//div[contains(text(),'Select Account Manager Name')])[1]")).click();
		List<WebElement> l10 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l10, "Sailaja GUDALA");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[contains(text(),'Select Account Manager Approval')]")).click();
		List<WebElement> l11 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l11, "NO");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[contains(text(),'Select Account Manager Approval')]")).click();
		List<WebElement> l12 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l12, "Fixed Bid");
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//div[contains(text(),'Select Project/Position Duration')])[1]")).click();
		List<WebElement> l13 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l13, "9 Months");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[contains(text(),'Select Currency')]")).click();
		List<WebElement> l14 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l14, "Cedis");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[contains(text(),'Select Period')]")).click();
		List<WebElement> l15 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l15, "Monthly");
		Thread.sleep(1000);
		driver.findElement(By.id("//input[@id=':r1m:']")).sendKeys("1000");
		Thread.sleep(1000);
		driver.findElement(By.xpath(
			"(//div[contains(@class,'MuiInputBase-root MuiOutlinedInput-root MuiInputBase-colorPrimary Mui-error add__select css-bnwvx5')])[1]"))
			.click();
		List<WebElement> l16 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l16, "Full Time");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id=':r1r:']")).sendKeys("1000");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id=':r1s:']")).sendKeys("1000");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id=':r1u:']")).sendKeys("10");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id=':r1v:']")).sendKeys("10");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id=':r20:']")).sendKeys("10");
		Thread.sleep(1000);
		driver.findElement(By.xpath(
			"//div[contains(@class,'MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-12 MuiGrid-grid-lg-12 css-15j76c0')]//div[contains(@aria-label,'Edit text')]"))
			.sendKeys(
				"//div[contains(@class,'MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-12 MuiGrid-grid-lg-12 css-15j76c0')]//div[contains(@aria-label,'Edit text')]");
		Thread.sleep(1000);
		driver.findElement(By.xpath(
			"//div[@class='MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-4 MuiGrid-grid-lg-12 css-1na5l02']//div[@aria-label='Edit text']"))
			.sendKeys(
				"//div[@class='MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-4 MuiGrid-grid-lg-12 css-1na5l02']//div[@aria-label='Edit text']");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id=':r21:']")).sendKeys("10");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[contains(text(),'Select Designation')]")).click();
		List<WebElement> l17 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l17, "Director");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id=':r22:']")).sendKeys("03/01/2024");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[contains(text(),'Select Work Mode')]")).click();
		List<WebElement> l18 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l18, "Office");
		Thread.sleep(1000);
		driver.findElement(By.xpath(
			"//div[contains(@class,'MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-12 MuiGrid-grid-lg-12 css-15j76c0')]//div[contains(@aria-label,'Edit text')]"))
			.sendKeys(
				"//div[contains(@class,'MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-12 MuiGrid-grid-md-12 MuiGrid-grid-lg-12 css-15j76c0')]//div[contains(@aria-label,'Edit text')]");
		Thread.sleep(1000);
		driver.findElement(By.xpath(
			"//body/div[@id='root']/main/div[contains(@class,'base_layout_wrapper MuiBox-root css-k008qs')]/main[contains(@class,'innerContentWrapper css-rph5bq')]/form[contains(@class,'createRRF mt-72 pt-2')]/div[contains(@class,'MuiContainer-root MuiContainer-maxWidthLg addCandidate__container css-1qsxih2')]/div[1]/div[1]/div[1]/div[1]"))
			.click();
		List<WebElement> l19 =
			driver.findElements(By.xpath("//ul[@class='MuiList-root MuiList-padding MuiMenu-list css-r8u8y9']//li"));
		multiSelectMethod(l19, "Office");
		Thread.sleep(1000);
	}

	public static void multiSelectMethod(List<WebElement> elements, String valve) throws InterruptedException {
		for (WebElement webElement : elements) {
			if (webElement.getText().equals(valve)) {
				// Thread.sleep(2000);
				webElement.click();
				break;
			}
		}
	}
}
