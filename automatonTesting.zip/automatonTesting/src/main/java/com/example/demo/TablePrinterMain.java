package com.example.demo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TablePrinterMain {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		// Initialize ChromeDriver
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.w3schools.com/html/html_tables.asp");
		// Locate the table element
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,450)");
		WebElement table = driver.findElement(By.id("customers"));
		// Print table headers
		WebElement headerRow = table.findElement(By.tagName("tbody")).findElement(By.tagName("tr"));
		List<WebElement> headerColumns = headerRow.findElements(By.tagName("th"));
		for (WebElement headerColumn : headerColumns) {
			System.out.print(headerColumn.getText() + "\t\t"); // assuming you want to use tab separator
		}
		// System.out.println(); // move to the next line
		List<WebElement> rows = table.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));
		for (WebElement row : rows) {
			List<WebElement> columns = row.findElements(By.tagName("td"));
			for (int i = 0; i < columns.size(); i++) {
				System.out.print(columns.get(i).getText());
				if (i < columns.size() - 1) {
					System.out.print("\t\t");
				}
			}
			System.out.println(); // move to the next line for the next row
		}
	}
}
