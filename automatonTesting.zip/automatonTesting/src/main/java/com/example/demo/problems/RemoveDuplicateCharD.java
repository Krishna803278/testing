package com.example.demo.problems;

public class RemoveDuplicateCharD {
	// public static void main(String[] args) {
	// String str = "JavaisaprogramminglanguageanJavaisalsoaplatform";
	// String result = removeDuplicateCharacters(str);
	// System.out.println("Original string: " + str);
	// System.out.println("String after removing duplicates: " + result);
	// }
	//
	// public static String removeDuplicateCharacters(String str) {
	// return str//
	// .chars()//
	// .distinct()//
	// .mapToObj(c -> String.valueOf((char) c))//
	// .collect(Collectors.joining());
	// }
}
