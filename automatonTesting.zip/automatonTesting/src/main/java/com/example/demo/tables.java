package com.example.demo;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class tables {

	public static void main(String[] args) {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(500));
		driver.manage().window().maximize();
		driver.get("https://datatables.net/examples/data_sources/js_array.html");
		List<WebElement> element = driver.findElements(By.xpath("//table[@id='example']//tbody//td[1]"));
		int colums = driver.findElements(By.xpath("//table[@id='example']//thead//tr")).size();
		int row = driver.findElements(By.xpath("//table[@id='example']//tbody/tr")).size();
		String exactTest = driver.findElement(By.xpath("//table[@id='example']//tbody//tr[1]//td[4]")).getText();
		System.err.println("elementSize : " + element.size());
		for (int i = 0; i < element.size(); i++) {
			String str = element.get(i).getText();
			System.out.println(str);
		}
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < colums; j++) {
				String exactText = driver
					.findElement(By.xpath("//table[@id='example']//tbody//tr[" + j + "]//td[" + i + "]")).getText();
				System.err.println(exactText + " ");
			}
			System.out.println();
		}
		driver.quit();
	}
}
