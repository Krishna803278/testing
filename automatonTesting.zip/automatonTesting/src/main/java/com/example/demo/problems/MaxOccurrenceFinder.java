package com.example.demo.problems;

import java.util.LinkedHashMap;
import java.util.Map;

public class MaxOccurrenceFinder {

	public static void main(String[] args) {
		String str = "abcderfacc";
		char maxChar = findMaxOccurrence(str);
		System.out.println("Character with maximum occurrence: '" + maxChar + "'");
	}

	public static char findMaxOccurrence(String str) {
		Map<Character, Integer> charOccurrences = new LinkedHashMap<>();
		for (char ch : str.toCharArray()) {
			charOccurrences.put(ch, charOccurrences.getOrDefault(ch, 0) + 1);
		}
		char maxChar = '\0'; // Initialize with null character
		int maxCount = 0;
		for (Map.Entry<Character, Integer> entry : charOccurrences.entrySet()) {
			if (entry.getValue() > maxCount) {
				maxCount = entry.getValue();
				maxChar = entry.getKey();
			}
		}
		return maxChar;
	}
}
