package com.example.demo;

public class wait {

	public static void main(String[] args) {
		// WebDriverManager.edgedriver().setup();
		// WebDriver driver = new EdgeDriver();
		// driver.get("https://rahulshettyacademy.com/seleniumPractise/");
		// System.out.println(driver.getTitle());
		// String[] prodects = {"Brocolli", "Carrot", "Tomato"};
		// List<String> listproducts = Arrays.asList(prodects);
		// List<WebElement> prodect = driver.findElements(By.cssSelector("h4.product-name"));
		// for (int i = 0; i < prodect.size(); i++) {
		// String name = prodect.get(i).getText();
		// if (listproducts.contains(name)) {
		// driver.findElements(By.xpath("//button[text()='ADD TO CART']")).get(i).click();
		// break;
		// }
		// }
	}
}
