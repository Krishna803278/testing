package com.example.demo.problems;

import java.util.HashMap;
import java.util.Map;

public class StringRepeatedCharactersArrys2 {

	public static void main(String[] args) {
		// String[] array1 = {"Hello"};
		String[] array1 = {"Hello", "World", "Holla"};
		String repeatedChars = getRepeatedCharacters(array1);
		System.out.println("Repeated characters: " + repeatedChars);
	}

	public static String getRepeatedCharacters(String[] array) {
		Map<Character, Integer> charCountMap = new HashMap<>();
		StringBuilder result = new StringBuilder();
		// Count occurrences of each character
		for (String str : array) {
			for (int i = 0; i < str.length(); i++) {
				char ch = str.charAt(i);
				charCountMap.put(ch, charCountMap.getOrDefault(ch, 0) + 1);
			}
		}
		// Collect characters that appear more than once
		for (Map.Entry<Character, Integer> entry : charCountMap.entrySet()) {
			if (entry.getValue() > 1) {
				result.append(entry.getKey());
			}
		}
		return result.toString();
	}
}
