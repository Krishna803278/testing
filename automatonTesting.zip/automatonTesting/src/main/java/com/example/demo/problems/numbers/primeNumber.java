package com.example.demo.problems.numbers;

import java.util.Scanner;
import java.util.stream.IntStream;

public class primeNumber {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.err.println("enterNumber :- ");
		int number = scanner.nextInt();
		IntStream.rangeClosed(2, number).filter(primeNumber::isPrime).forEach(System.out::println);
		// int number = 10;
		// if (isPrime(number)) {
		// System.err.println("prime ");
		// } else {
		// System.err.println("not a prime");
		// }
		scanner.close();
	}

	public static Boolean isPrime(int number) {
		if (number <= 1) {
			return false;
		}
		for (int i = 2; i < Math.sqrt(number); i++) {
			if (number % i == 0) {
				return false;
			}
		}
		return true;
	}
}
