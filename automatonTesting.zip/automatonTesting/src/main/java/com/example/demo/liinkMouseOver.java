package com.example.demo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class liinkMouseOver {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		List<WebElement> ss =
			driver.findElements(By.xpath("//div[@class='navFooterVerticalRow navAccessibility']//li"));
		System.err.println(" titalLInkSize : " + ss.size());
		Actions actions = new Actions(driver);
		for (WebElement link : ss) {
			actions.moveToElement(link).perform();
			Thread.sleep(3000);
		}
		driver.quit();
	}
}
