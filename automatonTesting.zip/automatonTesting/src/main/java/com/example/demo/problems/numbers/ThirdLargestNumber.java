package com.example.demo.problems.numbers;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class ThirdLargestNumber {

	public static void main(String[] args) {
		int[] numbers = {10, 20, 5, 15, 56, 34, 4, 3, 23, 30};
		List<Integer> num = Arrays.stream(numbers).boxed().collect(Collectors.toList());
		Integer thirdLargest = findThirdLargest(num);
		System.out.println("findThirdLargest: " + thirdLargest);
		System.out.println("print findLargestThree");
		List<Integer> largestThree = findLargestThree(num);
		System.out.println("Largest three numbers: " + largestThree);
		System.out.println("print sortedReverseOrder");
		List<Integer> sortedReverse = sortInReverseOrder(num);
		System.out.println("Sorted in reverse order: " + sortedReverse);
	}

	public static Integer findThirdLargest(List<Integer> list) {
		return list.stream().distinct()//
			.sorted(Collections.reverseOrder())//
			.skip(2)//
			.findFirst()//
			.get();
	}

	public static List<Integer> findLargestThree(List<Integer> list) {
		return list.stream().distinct()//
			.sorted(Collections.reverseOrder())//
			.limit(3)//
			.collect(Collectors.toList());//
	}

	public static List<Integer> sortInReverseOrder(List<Integer> list) {
		return list.stream()//
			.sorted(Collections.reverseOrder())//
			.collect(Collectors.toList());
	}
}
