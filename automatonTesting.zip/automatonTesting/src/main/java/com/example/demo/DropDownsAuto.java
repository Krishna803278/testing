package com.example.demo;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDownsAuto {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(500));
		driver.manage().window().maximize();
		driver.get("https://www.bing.com/");
		// driver.switchTo().alert().dismiss();
		driver.findElement(By.id("sb_form_q")).sendKeys("sele");
		List<WebElement> elements = driver.findElements(By.xpath("//ul[@role='listbox']//li"));
		System.err.println("Total Elements: " + elements.size());
		// mutiDropDown(elements, "selenium");
		printAllDropDownValues(elements);
		selectLastDropDownValue(elements);
		System.err.println(driver.findElement(By.id("sb_form_q")).getText());
		// driver.quit();
	}

	public static void mutiDropDown(List<WebElement> element, String Value) {
		for (WebElement option : element) {
			if (option.getText().contains(Value)) {
				option.click();
				break;
			}
		}
	}

	public static void printAllDropDownValues(List<WebElement> elements) {
		for (WebElement option : elements) {
			System.out.println(option.getText());
		}
	}

	public static void selectLastDropDownValue(List<WebElement> elements) throws InterruptedException {
		if (!elements.isEmpty()) {
			WebElement lastOption = elements.get(elements.size() - 1);
			// Thread.sleep(1000);
			lastOption.click();
		}
	}
}
