package com.example.demo;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Frame {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new ChromeDriver();
		String parentWindowAddres = driver.getWindowHandle();
		driver.get("https://www.hyrtutorials.com/p/window-handles-practice.html");
		driver.manage().window().maximize();
		driver.findElement(By.id("newTabBtn")).click();
		Set<String> totalWindos = driver.getWindowHandles();
		System.err.println("parentWindowAddres : " + parentWindowAddres);
		for (String windows : totalWindos) {
			if (!windows.equals(parentWindowAddres)) {
				driver.switchTo().window(windows);
				System.out.println(windows + driver.getTitle());
				driver.manage().window().maximize();
				driver.findElement(By.id("alertBox")).click();
				driver.switchTo().alert().accept();
				driver.switchTo().frame(12);
				Thread.sleep(5000);
				driver.close();
			}
		}
		// totalWindos. forEach(s -> System.err.println("totalWindos : " + s));
		driver.switchTo().window(parentWindowAddres);
		driver.findElement(By.id("name")).sendKeys("krishna");
		Thread.sleep(5000);
		driver.quit();
	}
}
