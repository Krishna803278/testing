package com.example.demo.problems;

import java.util.LinkedHashMap;
import java.util.Map;

public class CharacterNumbrCount {

	// SeparateCharactersCount
	public static void main(String[] args) {
		String str = "ab   1234 cderfa @#$ ";
		StringBuilder letters = new StringBuilder();
		StringBuilder numbers = new StringBuilder();
		StringBuilder specialChars = new StringBuilder();
		Map<Character, Integer> charOccurrences = countCharacterOccurrences(str);
		int totalDigitCount = 0;
		int totalLetterCount = 0;
		int totalSpecialCharCount = 0;
		for (Map.Entry<Character, Integer> entry : charOccurrences.entrySet()) {
			char ch = entry.getKey();
			if (Character.isDigit(ch)) {
				numbers.append(ch);
				totalDigitCount++;
			} else if (Character.isLetter(ch)) {
				totalLetterCount++;
				letters.append(ch);
			} else {
				totalSpecialCharCount++;
				specialChars.append(ch);
			}
		}
		System.out.println("Letters: " + letters.toString());
		System.out.println("Numbers: " + numbers.toString());
		System.out.println("Special Characters: " + specialChars.toString());
		System.out.println("Total number of digits: " + totalDigitCount);
		System.out.println("Total number of letters: " + totalLetterCount);
		System.out.println("Total number of special characters: " + totalSpecialCharCount);
	}

	public static Map<Character, Integer> countCharacterOccurrences(String str) {
		Map<Character, Integer> charOccurrences = new LinkedHashMap<>();
		for (char ch : str.toCharArray()) {
			charOccurrences.put(ch, charOccurrences.getOrDefault(ch, 0) + 1);
		}
		return charOccurrences;
	}
}
