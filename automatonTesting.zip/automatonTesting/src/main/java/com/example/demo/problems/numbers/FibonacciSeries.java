package com.example.demo.problems.numbers;

public class FibonacciSeries {

	public static void main(String[] args) {
		int n = 10; // Number of terms to generate
		System.out.println("Fibonacci series using iterative approach:");
		printFibonacciIterative(n);
	}

	public static void printFibonacciIterative(int n) {
		int a = 0, b = 1;
		for (int i = 1; i <= n; i++) {
			System.out.print(a + " ");
			int next = a + b;
			a = b;
			b = next;
		}
		System.out.println();
	}
}
