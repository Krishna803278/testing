package com.example.demo.problems;

import java.util.LinkedHashMap;
import java.util.Map;

public class CharacterOccurrences {

	public static void main(String[] args) {
		String str = "abcderfa ";
		Map<Character, Integer> charOccurrences = countCharacterOccurrences(str);
		int nonRepeatedCount = 0;
		for (Map.Entry<Character, Integer> entry : charOccurrences.entrySet()) {
			if (entry.getValue() == 1) {
				nonRepeatedCount++;
				if (nonRepeatedCount == 2) {
					System.out.println("2st non-repeated character in the string:");
					System.out.println("'" + entry.getKey() + "' : " + entry.getValue());
					break;
				}
			}
		}
	}

	public static Map<Character, Integer> countCharacterOccurrences(String str) {
		Map<Character, Integer> charOccurrences = new LinkedHashMap<>();
		for (char ch : str.toCharArray()) {
			// if (ch != ' ') {
			charOccurrences.put(ch, charOccurrences.getOrDefault(ch, 0) + 1);
			// }
		}
		return charOccurrences;
	}
}
