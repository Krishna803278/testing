package com.example.demo.problems.numbers;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class MissingNumberFinder {

	public static void main(String[] args) {
		// Example with array
		int[] array = {1, 2, 4, 5, 6, 7, 9};
		List<Integer> missingNumbersFromArray =
			findMissingNumbers(Arrays.stream(array).boxed().collect(Collectors.toList()));
		System.out.println("Missing numbers from array: " + missingNumbersFromArray);
		// Example with list
		// List<Integer> list = Arrays.asList(1, 22);
		// List<Integer> missingNumbersFromList = findMissingNumbers(list);
		// System.out.println("Missing numbers from list: " + missingNumbersFromList);
	}

	private static List<Integer> findMissingNumbers(List<Integer> valve) {
		Set<Integer> numbersSet = new HashSet<>(valve);
		int start = valve.stream().min(Integer::compareTo).orElseThrow();
		int end = valve.stream().max(Integer::compareTo).orElseThrow();
		return IntStream//
			.rangeClosed(start, end)//
			.filter(num -> !numbersSet.contains(num))//
			.boxed()//
			.collect(Collectors.toList());
	}
}
