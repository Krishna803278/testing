package com.example.demo.problems;

public class VowelConsonantCounter {

	public static void main(String[] args) {
		String str = "Hello World234 @#";
		int vowelCount = 0;
		int consonantCount = 0;
		StringBuilder vowels = new StringBuilder();
		StringBuilder consonants = new StringBuilder();
		for (char ch : str.toLowerCase().toCharArray()) {
			// if (ch >= 'a' && ch <= 'z') {
			if (isVowel(ch)) {
				vowelCount++;
				vowels.append(ch);
			} else {
				consonantCount++;
				consonants.append(ch);
				// }
			}
		}
		System.out.println("Vowels Count : " + vowelCount);
		System.out.println("Consonants Count: " + consonantCount);
		System.out.println("Vowels: " + vowels);
		System.out.println("Consonants: " + consonants);
	}

	public static boolean isVowel(char ch) {
		return ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u';
	}
}
