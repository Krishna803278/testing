package com.example.demo.problems.numbers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UniquePairs2 {

	public static List<int[]> findUniquePairs(List<Integer> values, int value) {
		// Convert list to array
		int[] arr = values.stream().mapToInt(Integer::intValue).toArray();
		Arrays.sort(arr);
		int left = 0;
		int right = 1;
		List<int[]> result = new ArrayList<>();
		while (right < arr.length) {
			int diff = arr[right] - arr[left];
			if (diff == value) {
				result.add(new int[] {arr[left], arr[right]});
				left++;
				right++;
			} else if (diff < value) {
				right++;
			} else {
				left++;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		List<Integer> values = Arrays.asList(4, 8, 2, 6, 5);
		int value = 3;
		List<int[]> output = findUniquePairs(values, value);
		System.out.println("Output:");
		for (int[] pair : output) {
			System.out.println(Arrays.toString(pair));
		}
	}
}
