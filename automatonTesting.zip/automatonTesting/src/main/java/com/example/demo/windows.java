package com.example.demo;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class windows {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		String parentWindowAddres = driver.getWindowHandle();
		driver.get("https://www.hyrtutorials.com/p/window-handles-practice.html");
		driver.findElement(By.id("newWindowBtn")).click();
		Set<String> totalWindos = driver.getWindowHandles();
		System.err.println("parentWindowAddres : " + parentWindowAddres);
		for (String windows : totalWindos) {
			if (!windows.equals(parentWindowAddres)) {
				driver.switchTo().window(windows);
				System.out.println(windows + driver.getTitle());
				driver.manage().window().maximize();
				driver.findElement(By.id("lastName")).sendKeys("krishna");
				Thread.sleep(5000);
				// driver.close();
				driver.switchTo().window(windows);
				Thread.sleep(5000);
				driver.quit();
			}
		}
		// totalWindos. forEach(s -> System.err.println("totalWindos : " + s));
		driver.switchTo().window(parentWindowAddres);
		driver.findElement(By.id("name")).sendKeys("krishna");
		Thread.sleep(5000);
		driver.quit();
	}
}
