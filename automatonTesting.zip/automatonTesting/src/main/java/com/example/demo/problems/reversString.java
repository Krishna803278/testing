package com.example.demo.problems;

public class reversString {

	public static void main(String[] args) {
		String str = "hello world abc";
		// cba dlrow olleh
		String reversed = reverse(str);
		System.out.println(reversed);
		// // Palindrome code
		// if (isPalindrome(str)) {
		// System.out.println(str + " is a palindrome.");
		// } else {
		// System.out.println(str + " is not a palindrome.");
		// }
	}

	public static String reverse(String str) {
		char[] charArray = str.toCharArray();
		int length = charArray.length;
		for (int i = 0; i < length / 2; i++) {
			char temp = charArray[i];
			charArray[i] = charArray[length - i - 1];
			charArray[length - i - 1] = temp;
		}
		return new String(charArray);
	}

	public static boolean isPalindrome(String str) {
		String reversed = reverse(str);
		return str.equals(reversed);
	}
}
