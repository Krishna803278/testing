package com.example.demo.problems;

public class ReversWordsString {

	public static void main(String[] args) {
		String str = "hello world java program";
		String reversed = reverseWord(str);
		System.out.println(reversed);
	}

	public static String reverseWord(String str) {
		// olleh dlrow avaj margorp
		String[] words = str.split(" ");
		StringBuffer sb = new StringBuffer();
		for (String word : words) {
			sb.append(reverse(word)).append(" ");
		}
		return sb.toString().trim();
	}

	public static String reverse(String str) {
		char[] charArray = str.toCharArray();
		int length = charArray.length;
		for (int i = 0; i < length / 2; i++) {
			char temp = charArray[i];
			charArray[i] = charArray[length - i - 1];
			charArray[length - i - 1] = temp;
		}
		return new String(charArray);
	}
}
