package com.example.demo.problems.numbers.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class practice {

	public static List<Integer> findLargestNNumbers(List<Integer> arr) {
		List<Integer> p = new ArrayList<Integer>();
		List<Integer> n = new ArrayList<Integer>();
		for (int num : arr) {
			if (num >= 0) {
				p.add(num);
			} else {
				n.add(num);
			}
		}
		p.addAll(n);
		return p;
	}

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(-3, 5, -7, 51, -33, 8, 9, 19, 6);
		List<Integer> num = new ArrayList<>();
		List<Integer> largestNNumbers = findLargestNNumbers(numbers);
		for (int nummber : largestNNumbers) {
			System.out.print(nummber + " ");
		}
		// System.out.println("The largest unique numbers are: " + largestNNumbers);
	}
}
