package com.example.demo;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class linkBroken {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://github.com/this-is-a-non-existent-page");
		WebElement element = driver.findElement(By.xpath("//div[@class='container-xl p-responsive']"));
		List<WebElement> allLinks = element.findElements(By.tagName("a"));
		for (WebElement link : allLinks) {
			String url = link.getAttribute("href");
			if (url != null && !url.isEmpty()) {
				try {
					HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
					connection.setRequestMethod("HEAD");
					connection.connect();
					int responseCode = connection.getResponseCode();
					if (responseCode >= 400) {
						System.out.println("Broken link: " + url);
					} else {
						System.out.println("Valid link: " + url);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		// Close the WebDriver
		driver.quit();
	}
}
