package com.example.demo.problems;

import java.util.Arrays;
import java.util.stream.Stream;

public class MergedArrayCancat {

	public static void main(String[] args) {
		String[] array1 = {"Hello", "Java"};
		String[] array2 = {"Java", "Program"};
		String[] mergedArray =
			Stream.concat(Arrays.stream(array1), Arrays.stream(array2)).distinct().toArray(String[]::new);
		// Print the merged array
		System.out.println("Merged Array: " + Arrays.toString(mergedArray));
	}
}
