package com.example.demo.problems;

public class CapitalizeWordsStringUpper3 {

	public static void main(String[] args) {
		String str = "hello@world#java0program2Am";
		String processedStr = processString(str);
		System.out.println(processedStr);
	}

	public static String processString(String str) {
		String[] words = str.split("[^a-zA-Z]+");
		StringBuilder resultStr = new StringBuilder();
		for (String word : words) {
			resultStr.append(word).append("\n");
		}
		return resultStr.toString().trim();
	}
}
