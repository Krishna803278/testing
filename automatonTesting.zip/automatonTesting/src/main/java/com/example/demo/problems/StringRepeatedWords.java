package com.example.demo.problems;

public class StringRepeatedWords {

	public static void main(String[] args) {
		String str1 = "Hello AP World";
		String str2 = "Java World AP";
		String repeatedChars = getRepeatedWords(str1, str2);
		System.out.println("Repeated characters: " + repeatedChars);
	}

	public static String getRepeatedWords(String str1, String str2) {
		StringBuilder result = new StringBuilder();
		for (String word1 : str1.split(" ")) {
			for (String word2 : str2.split(" ")) {
				if (word1.equals(word2) && result.indexOf(word1) == -1) {
					result.append(word1).append(" ");
				}
			}
		}
		return result.toString();
	}
}
