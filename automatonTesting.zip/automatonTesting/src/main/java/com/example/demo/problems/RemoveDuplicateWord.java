package com.example.demo.problems;

public class RemoveDuplicateWord {
	// public static void main(String[] args) {
	// String str = "Java is a programming language and Java is also a platform";
	// String result = removeDuplicateWords(str);
	// System.out.println("Original string: " + str);
	// System.out.println("String after removing duplicates: " + result);
	// }
	//
	// public static String removeDuplicateWords(String str) {
	// return Arrays//
	// .stream(str.split(" "))//
	// .distinct()//
	// .collect(Collectors.joining(" "));
	// }
}
