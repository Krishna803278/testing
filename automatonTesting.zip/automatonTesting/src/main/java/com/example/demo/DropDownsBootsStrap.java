package com.example.demo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDownsBootsStrap {

	public static void main(String[] args) {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.hdfcbank.com/");
		driver.findElement(By.xpath("//a[.='Select Product Type']")).click();
		List<WebElement> listElement = driver.findElements(By.xpath("//ul[@class='dropdown1 dropdown-menu']//li"));
		System.out.println(listElement.size());
		// driver.switchTo().alert().
		multiSelectMethod(listElement, "Cards");
		driver.findElement(By.xpath("//a[.='Select Product']")).click();
		List<WebElement> listElement2 = driver.findElements(By.xpath("//ul[@class='dropdown2 dropdown-menu']//li"));
		System.out.println(listElement.size());
		multiSelectMethod(listElement2, "Debit Cards");
	}

	public static void multiSelectMethod(List<WebElement> elements, String valve) {
		for (WebElement webElement : elements) {
			if (webElement.equals(valve)) {
				webElement.click();
				break;
			}
		}
	}
}
