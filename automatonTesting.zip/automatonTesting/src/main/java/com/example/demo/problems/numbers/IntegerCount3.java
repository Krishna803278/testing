package com.example.demo.problems.numbers;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class IntegerCount3 {

	public static void main(String[] args) {
		int[] arr = {45, 12, 56, 15, 15, 24, 75, 31, 8};
		List<Integer> listOfIntegers = Arrays.stream(arr).boxed().collect(Collectors.toList());
		Map<Integer, Integer> integerOccurrences = countIntegerOccurrences(listOfIntegers);
		for (Map.Entry<Integer, Integer> entry : integerOccurrences.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}

	public static Map<Integer, Integer> countIntegerOccurrences(List<Integer> list) {
		Map<Integer, Integer> integerOccurrences = new LinkedHashMap<>();
		for (Integer number : list) {
			integerOccurrences.put(number, integerOccurrences.getOrDefault(number, 0) + 1);
		}
		return integerOccurrences;
	}
}
