package com.example.demo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DropDownsSelectspecificCheckbox {

	public static void main(String[] args) {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.opencart.com/index.php?route=account/register");
		WebElement element = driver.findElement(By.id("aaa"));
		mutiDropDown(element, "aa");
		WebElement element1 = driver.findElement(By.id("bbb"));
		mutiDropDown(element1, "bbb");
		// Select select = new Select(driver.findElement(By.id("aaa")));
	}

	public static void mutiDropDown(WebElement element, String Value) {
		Select select = new Select(element);
		List<WebElement> webElement = select.getOptions();
		for (WebElement option : webElement) {
			if (option.getText().equalsIgnoreCase(Value)) {
				option.click();
				break;
			}
		}
	}
}
