package com.example.demo.problems;

import java.util.LinkedHashMap;
import java.util.Map;

public class WordOccurrences {

	public static void main(String[] args) {
		String str = "Java is a programming language and Java is also a platform";
		Map<String, Integer> charOccurrences = countCharacterOccurrences(str);
		for (Map.Entry<String, Integer> entry : charOccurrences.entrySet()) {
			System.out.println("'" + entry.getKey() + "' : " + entry.getValue());
		}
	}

	public static Map<String, Integer> countCharacterOccurrences(String str) {
		Map<String, Integer> charOccurrences = new LinkedHashMap<>();
		for (String word : str.split(" ")) {
			charOccurrences.put(word, charOccurrences.getOrDefault(word, 0) + 1);
		}
		return charOccurrences;
	}
}
