package com.example.demo.problems;

import java.util.Arrays;
import java.util.stream.Collectors;

public class RemoveDuplicateWord2 {

	public static void main(String[] args) {
		String str = "Java is a programming language and Java is also a platform";
		String removeWord = "Java";
		String result = removeWordAndDuplicates(str, removeWord);
		System.out.println("Original string: " + str);
		System.out.println("String after removing '" + removeWord + "' and duplicates: " + result);
	}

	public static String removeWordAndDuplicates(String str, String removeWord) {
		return Arrays//
			.stream(str.split(" "))//
			.filter(word -> !word.equalsIgnoreCase(removeWord)) // Remove the specified
			.collect(Collectors.joining(" "));
	}
}
