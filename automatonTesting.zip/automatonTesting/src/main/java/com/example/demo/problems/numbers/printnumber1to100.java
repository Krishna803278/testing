package com.example.demo.problems.numbers;

public class printnumber1to100 {

	public static void main(String[] args) {
		printNumbers(1);
	}

	public static void printNumbers(int number) {
		if (number <= 100) {
			System.out.println(number);
			printNumbers(number + 1);
		}
	}
}
