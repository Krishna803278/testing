package com.example.demo.problems;

import java.util.stream.Collectors;

public class RemoveDuplicateChar3 {

	public static void main(String[] args) {
		String str = "Java is a programming language and Java is also a platform";
		char removeChar = 'a';
		String result = removeCharAndDuplicates(str, removeChar);
		System.out.println("Original string: " + str);
		System.out.println("String after removing '" + removeChar + "' and duplicates: " + result);
	}

	public static String removeCharAndDuplicates(String str, char removeChar) {
		return str.chars()//
			.mapToObj(c -> (char) c)//
			.filter(c -> c != removeChar)//
			.map(String::valueOf)//
			.collect(Collectors.joining());
	}
}
