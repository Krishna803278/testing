package com.example.demo.problems.numbers;

import java.util.List;
import java.util.stream.Collectors;

public class RepeatedNumbers {

	public static void main(String[] args) {
		List<Integer> list1 = List.of(1, 2, 3, 4, 5);
		List<Integer> list2 = List.of(3, 4, 5, 6, 7);
		List<Integer> repeatedNumbers = getRepeatedNumbers(list1, list2);
		System.out.println("List 1: " + list1);
		System.out.println("List 2: " + list2);
		System.out.println("Repeated numbers : " + repeatedNumbers); // Output: [3, 4, 5]
	}

	public static List<Integer> getRepeatedNumbers(List<Integer> list1, List<Integer> list2) {
		return list1//
			.stream()//
			.filter(list2::contains)//
			.distinct()//
			.collect(Collectors.toList());
	}
}
