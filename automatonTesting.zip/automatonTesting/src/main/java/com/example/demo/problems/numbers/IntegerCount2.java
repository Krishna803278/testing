package com.example.demo.problems.numbers;

import java.util.LinkedHashMap;
import java.util.Map;

public class IntegerCount2 {

	public static void main(String[] args) {
		int num = 12345678;
		Map<Character, Integer> digitOccurrences = countDigitOccurrences(num);
		for (Map.Entry<Character, Integer> entry : digitOccurrences.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}

	public static Map<Character, Integer> countDigitOccurrences(int num) {
		Map<Character, Integer> digitOccurrences = new LinkedHashMap<>();
		String numStr = String.valueOf(num);
		for (char digit : numStr.toCharArray()) {
			digitOccurrences.put(digit, digitOccurrences.getOrDefault(digit, 0) + 1);
		}
		return digitOccurrences;
	}
}
