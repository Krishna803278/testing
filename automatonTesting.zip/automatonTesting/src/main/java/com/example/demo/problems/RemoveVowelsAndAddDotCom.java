package com.example.demo.problems;

public class RemoveVowelsAndAddDotCom {

	public static void main(String[] args) {
		String name = "Krishna reddy";
		String result = removeVowels(name) + ".com";
		System.out.println(result);
	}

	public static String removeVowels(String input) {
		return input.replaceAll("[AEIOUaeiou] ", "");
	}
}
