package com.example.demo.problems.numbers.core;

import java.util.Arrays;
import java.util.List;

public class NthLargestNumber {

	public static Integer findNthLargest(int[] array, int n) {
		for (int i = 0; i < array.length - 1; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] < array[j]) {
					// Swap elements
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		return array[n - 1];
	}

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(3, 5, 7, 5, 3, 8, 9, 9, 6);
		int[] array = new int[numbers.size()];
		int index = 0;
		for (int num : numbers) {
			array[index++] = num;
		}
		int n = 3;
		Integer nthLargest = findNthLargest(array, n);
		System.out.println("The " + n + "-th largest number is: " + nthLargest);
	}
}
