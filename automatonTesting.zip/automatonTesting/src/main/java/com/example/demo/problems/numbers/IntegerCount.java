package com.example.demo.problems.numbers;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class IntegerCount {

	public static void main(String[] args) {
		List<Integer> listOfIntegers = Arrays.asList(45, 12, 56, 15, 15, 24, 75, 31, 89);
		Map<Integer, Integer> integerOccurrences = countIntegerOccurrences(listOfIntegers);
		for (Map.Entry<Integer, Integer> entry : integerOccurrences.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}

	public static Map<Integer, Integer> countIntegerOccurrences(List<Integer> list) {
		Map<Integer, Integer> integerOccurrences = new LinkedHashMap<>();
		for (Integer number : list) {
			integerOccurrences.put(number, integerOccurrences.getOrDefault(number, 0) + 1);
		}
		return integerOccurrences;
	}
}
