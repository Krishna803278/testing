package com.example.demo;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class liink {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.amazon.in/");
		WebElement footer = driver.findElement(By.xpath("//div[@class='navFooterVerticalRow navAccessibility']"));
		int footerSize = footer.findElements(By.tagName("a")).size();
		System.out.println(" footerLinkSize : " + footerSize);
		for (int i = 0; i < footerSize; i++) {
			String enterKey = Keys.chord(Keys.CONTROL, Keys.ENTER);
			footer.findElements(By.tagName("a")).get(i).sendKeys(enterKey);
			Thread.sleep(5000);
		}
		// get title
		Set<String> windowHandles = driver.getWindowHandles();
		windowHandles.forEach(handle -> {
			driver.switchTo().window(handle);
			System.out.println(driver.getTitle());
		});
	}
}
