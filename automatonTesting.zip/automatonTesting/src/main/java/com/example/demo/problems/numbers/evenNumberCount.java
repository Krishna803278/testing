package com.example.demo.problems.numbers;

import java.util.ArrayList;
import java.util.List;

public class evenNumberCount {

	public static void main(String[] args) {
		int evenCount = 0;
		int oddCount = 0;
		List<Integer> evenNumber = new ArrayList<Integer>();
		List<Integer> oddNumber = new ArrayList<Integer>();
		int startNumber = 0;
		int endNUmber = 20;
		for (int i = startNumber; i <= endNUmber; i++) {
			if (i % 2 == 0) {
				evenCount++;
				evenNumber.add(i);
			} else {
				oddCount++;
				oddNumber.add(i);
			}
		}
		System.out.println("Number of even Count : " + evenCount);
		System.out.println("Number of odd Count : " + oddCount);
		System.out.println("Number of even  : " + evenNumber);
		System.out.println("Number of odd  : " + oddNumber);
	}
}
