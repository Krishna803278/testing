package com.example.demo.problems;

public class reversString2 {

	public static void main(String[] args) {
		String str = "hello world java program";
		// program java world hello
		String reversed = reverseWords(str);
		System.out.println(reversed);
	}

	public static String reverseWords(String str) {
		String[] words = str.split(" ");
		int length = words.length;
		for (int i = 0; i < length / 2; i++) {
			String temp = words[i];
			words[i] = words[length - i - 1];
			words[length - i - 1] = temp;
		}
		// Join the words back into a string
		return String.join(" ", words);
	}
}
