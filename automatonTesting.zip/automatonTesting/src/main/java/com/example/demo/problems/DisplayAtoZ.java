package com.example.demo.problems;

public class DisplayAtoZ {

	public static void main(String[] args) { // Main method
		// Step 3: Initialize i to 65 and Step 4: Continue as long as i is less than or equal to 90
		for (int i = 65; i <= 90; i++) {
			// Step 5: Cast i to char and print the character
			System.out.println((char) i + " - " + i);
		}
	}
}
