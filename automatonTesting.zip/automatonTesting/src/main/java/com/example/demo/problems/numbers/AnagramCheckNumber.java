package com.example.demo.problems.numbers;

import java.util.Arrays;

public class AnagramCheckNumber {

	public static void main(String[] args) {
		int num = 112;
		int num2 = 121;
		if (checkNumberAnagram(num, num2)) {
			System.out.println(num + " and " + num2 + " are anagrams.");
		} else {
			System.out.println(num + " and " + num2 + " are not anagrams.");
		}
	}

	public static Boolean checkNumberAnagram(int input1, int input2) {
		String str = String.valueOf(input1);
		String str2 = String.valueOf(input2);
		char[] char1 = str.toCharArray();
		char[] char2 = str2.toCharArray();
		Arrays.sort(char1);
		Arrays.sort(char2);
		return Arrays.equals(char1, char2);
	}
}
