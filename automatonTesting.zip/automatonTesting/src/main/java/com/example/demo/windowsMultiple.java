package com.example.demo;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class windowsMultiple {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		String parentWindowAddres = driver.getWindowHandle();
		driver.get("https://www.hyrtutorials.com/p/window-handles-practice.html");
		driver.findElement(By.id("newTabsWindowsBtn")).click();
		Set<String> totalWindos = driver.getWindowHandles();
		System.err.println("parentWindowAddres : " + parentWindowAddres);
		for (int i = 0; i <= totalWindos.size(); i++) {
			System.err.println(driver.getTitle());
			System.err.println(driver.getCurrentUrl());
		}
	}
}
