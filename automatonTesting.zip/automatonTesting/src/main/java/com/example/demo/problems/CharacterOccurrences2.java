package com.example.demo.problems;

import java.util.LinkedHashMap;
import java.util.Map;

public class CharacterOccurrences2 {

	public static void main(String[] args) {
		String str = "ab   cderfa ";
		Map<Character, Integer> charOccurrences = countCharacterOccurrences(str);
		for (Map.Entry<Character, Integer> entry : charOccurrences.entrySet()) {
			System.out.println("'" + entry.getKey() + "' : " + entry.getValue());
		}
	}

	public static Map<Character, Integer> countCharacterOccurrences(String str) {
		Map<Character, Integer> charOccurrences = new LinkedHashMap<>();
		for (char ch : str.toCharArray()) {
			charOccurrences.put(ch, charOccurrences.getOrDefault(ch, 0) + 1);
		}
		return charOccurrences;
	}
}
