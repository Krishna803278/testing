package com.example.demo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TablePrinter {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		// Initialize ChromeDriver
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.w3schools.com/html/html_tables.asp");
		// Locate the table element
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,450)");
		WebElement table = driver.findElement(By.id("customers"));
		List<WebElement> tableRow = table.findElements(By.xpath("//table[@id='customers']//tbody/tr/th"));
		System.err.println("tableRow :" + tableRow.size());
		List<WebElement> tableColom = table.findElements(By.xpath("//table[@id='customers']//tbody/tr"));
		System.err.println("tableColom :" + tableColom.size());
		// Remove the first row from the list
		if (!tableColom.isEmpty()) {
			tableColom.remove(1);
		}
		System.err.println("remove Colom :" + tableColom.size());
	}
}
