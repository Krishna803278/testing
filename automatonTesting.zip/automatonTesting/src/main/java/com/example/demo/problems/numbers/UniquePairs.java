package com.example.demo.problems.numbers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UniquePairs {

	public static List<int[]> findUniquePairs(int[] arr, int value) {
		Arrays.sort(arr);
		int left = 0;
		int right = 1;
		List<int[]> result = new ArrayList<>();
		while (right < arr.length) {
			int diff = arr[right] - arr[left];
			if (diff == value) {
				result.add(new int[] {arr[left], arr[right]});
				left++;
				right++;
			} else if (diff < value) {
				right++;
			} else {
				left++;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		int[] arr = {4, 8, 2, 6, 5};
		int value = 4;
		List<int[]> output = findUniquePairs(arr, value);
		System.out.println("Output:");
		for (int[] pair : output) {
			System.out.println(Arrays.toString(pair));
		}
	}
}
