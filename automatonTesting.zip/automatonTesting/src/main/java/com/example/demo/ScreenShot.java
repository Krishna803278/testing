package com.example.demo;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ScreenShot {

	public static void main(String[] args) throws InterruptedException, IOException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://en.wikipedia.org/wiki/Google");
		driver.manage().window().maximize();
		// take full page screen short
		// TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		// File src = takesScreenshot.getScreenshotAs(OutputType.FILE);
		// File trg = new File("C:\\Users\\balakrishnab\\Desktop\\EightFeaturesInJava\\screenshot\\homepage.png");
		// FileUtils.copyFile(src, trg);
		// take specific page screen short
		WebElement section = driver.findElement(By.xpath("//div[@class='div-col']"));
		File src = section.getScreenshotAs(OutputType.FILE);
		File trg = new File("C:\\Users\\balakrishnab\\Desktop\\EightFeaturesInJava\\screenshot\\SeeAlso.png");
		FileUtils.copyFile(src, trg);
	}
}
