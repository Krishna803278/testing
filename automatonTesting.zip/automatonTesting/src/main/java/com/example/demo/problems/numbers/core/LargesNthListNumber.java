package com.example.demo.problems.numbers.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LargesNthListNumber {

	// Function to find the largest 'n' unique numbers in the array
	public static List<Integer> findLargestNNumbers(int[] array, int n) {
		// Sort the array in descending order
		for (int i = 0; i < array.length - 1; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] < array[j]) {
					// Swap elements
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		// Collect the largest 'n' unique numbers
		List<Integer> result = new ArrayList<>();
		int count = 0;
		for (int i = 0; i < array.length && count < n; i++) {
			if (!result.contains(array[i])) {
				result.add(array[i]);
				count++;
			}
		}
		return result;
	}

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(3, 5, 7, 5, 3, 8, 9, 9, 6);
		int[] array = new int[numbers.size()];
		int index = 0;
		for (int num : numbers) {
			array[index++] = num;
		}
		// Number of largest unique elements to find
		int n = 3;
		List<Integer> largestNNumbers = findLargestNNumbers(array, n);
		System.out.println("The largest " + n + " unique numbers are: " + largestNNumbers);
	}
}
