package com.example.demo.problems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class practice {

	public static void main(String[] args) {
		String str = "hello a java world a java program";
		List<String> unique = new ArrayList<>();
		List<String> duplicate = new ArrayList<>();
		Map<String, Integer> map = new HashMap<>();
		// Count occurrences of each character
		String[] ch = str.split(" ");
		for (String c : ch) {
			map.put(c, map.getOrDefault(c, 0) + 1);
		}
		// Separate unique and duplicate characters
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			if (entry.getValue() > 1) {
				duplicate.add(entry.getKey());
			} else {
				unique.add(entry.getKey());
			}
		}
		System.out.println("Unique characters: " + unique);
		System.out.println("Duplicate characters: " + duplicate);
	}
}
