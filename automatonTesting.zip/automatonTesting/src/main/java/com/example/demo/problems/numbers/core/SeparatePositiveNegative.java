package com.example.demo.problems.numbers.core;

import java.util.ArrayList;
import java.util.List;

public class SeparatePositiveNegative {

	public static void main(String[] args) {
		int[] arr = {4, 8, 2, -6, 9, -5, -6, -1, -7, 2, +1};
		// List<Integer> num = Arrays.asList(4, 8, 2, -6, -5, -6, -1, -7, 2, 1);
		List<Integer> num = new ArrayList<>();
		for (int value : arr) {
			num.add(value);
		}
		// Separate positive and negative values
		List<Integer> result = separatePositiveNegative(num);
		// Print the result
		for (int nummber : result) {
			System.out.print(nummber + " ");
		}
	}

	public static List<Integer> separatePositiveNegative(List<Integer> list) {
		List<Integer> positive = new ArrayList<>();
		List<Integer> negative = new ArrayList<>();
		for (int num : list) {
			if (num >= 0) {
				positive.add(num);
			} else {
				negative.add(num);
			}
		}
		// Combine the positive and negative lists
		positive.addAll(negative);
		return positive;
	}
}
