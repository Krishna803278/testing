package com.example.demo.problems.numbers.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class reverOrder {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(3, 5, 7, 5, 1, 8, 9, 9, 6);
		// Convert List<Integer> to int[]
		int[] array = new int[numbers.size()];
		int index = 0;
		for (int num : numbers) {
			array[index++] = num;
		}
		// Sort array in descending order without using built-in sort methods
		for (int i = 0; i < array.length - 1; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i] < array[j]) {
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		// Convert int array back to List (if needed)
		List<Integer> sortedNumbers = new ArrayList<>();
		for (int num : array) {
			sortedNumbers.add(num);
		}
		// Print sorted numbers
		System.out.println("Sorted numbers in reverse order: " + sortedNumbers);
	}
}
